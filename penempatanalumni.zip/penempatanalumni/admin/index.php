<?php 
session_start();
include "../include/fungsi2.php";
$sesi	= $_SESSION['sesi'];

if($_SESSION['sesi'] == "" || $_SESSION['sesi']  == NULL || empty($_SESSION['sesi'])){
	echo "<center><font color='red'>Anda tidak diperkenankan memasuki halaman ini, jika anda belum <a href='../index.php'>login</a> !!</font></center>";
	exit;
}
function logout() {
	session_start();
	session_destroy();
	echo "<meta http-equiv='refresh' content='0; url=../index.php'>";
}

$utama="<center><span class='s'>Selamat Datang di Sistem Informasi Alumni Pelatihan Dinsosnakertrans Kota Surakarta <br><br> Untuk menggunakan, silakan memilih menu di samping kiri !. <br><br> Jangan lupa LOG OUT sebelum keluar</span></center>";
?>

<html>
<head>
<title>.:: Sistem Informasi Pelatihan Dinsosnakertrans ::.</title>
<link rel="stylesheet" type="text/css" href="../include/style.css" />
</head>

<body>
<table border=0 width="100%" bgcolor="#00cc00" cellpadding=2 cellspacing=2 >

	<tr>
		<td colspan="2"><img src="../image/header.jpg" width="100%" height="180px"><div style="position: absolute; width: 418px; height: 69px; z-index: 1; left:477px; top:44px" id="layer1">
<p align="right"><font color="#0000FF"><u><b>
<font size="7" face="Bookman Old Style"></font></b></u><br>
</font><b><font size="4"></font></b></div>
		</td>
	</tr>
	<tr>
		<td colspan=2><marquee onmouseover="this.stop();" behavior="alternate" onmouseout="this.start();">Halaman Administrasi</marquee>
		</td>
	</tr>
	<tr>
	<td width="20%" valign="top">
	<h3>Pilih Menu</h3>
	<div class="kotak">
	<ul>
	<li><a href="index.php">Home</a></li>
	<li><a href="?page=penempatan">Penempatan</a></li>
	<li><a href="?page=peserta">Data Alumni</a></li>
	<li><a href="?page=lembaga">Data Lembaga</a></li>
	<li><a href="?page=user">Edit User</a></li>
	<li><a href="?page=logout" onclick="return confirm('Anda yakin ingin Keluar ?')" >Log Out</a></li>
	</ul><br>
	</div>
	</td>
	<td width="80%" valign="top">
	<h3>
		<?php 
			$page	= isset($_GET['page']) ? $_GET['page'] : "";
			
			if(strstr($page,"peserta")) {
			$j="Menu Data Alumni";
			} else if(strstr($page,"penempatan")) {
			$j="Menu Data Penempatan";
			} else if(strstr($page,"user")) {
			$j="<!--<img src='../image/user.png' style='position: absolute;'>-->Menu Data User";
			} else {
			$j="Menu Utama";
			} 
			echo $j;
		?>
			</h3>
			<div class="tengah">
		<?php 
	//menu penempatan
	if($page=="penempatan") {
	include "../penempatan/lihat_penempatan.php";
	} else if($page=="input_penempatan") {
	include "../penempatan/$page.php";
	} else if($page=="act_input_penempatan") {
	include "../penempatan/$page.php"; 
	} else if($page=="edit_penempatan") {
	include "../penempatan/$page.php";
	} else if($page=="act_edit_penempatan") {
	include "../penempatan/$page.php";
	} else if($page=="act_hapus_penempatan") {
	include "../penempatan/$page.php";
	} else if($page=="detil_penempatan") {
	include "../penempatan/$page.php";
	//======== akhir menu transaksi =========
	
	//menu Peserta
	} else if($page=="peserta") {
	include "../peserta/lihat_peserta.php";
	} else if($page=="input_peserta") {
	include "../peserta/$page.php";
	} else if($page=="act_input_peserta") {
	include "../peserta/$page.php";
	} else if($page=="edit_peserta") {
	include "../peserta/$page.php";
	} else if($page=="act_edit_peserta") {
	include "../peserta/$page.php";
	} else if($page=="act_hapus_peserta") {
	include "../peserta/$page.php";
	} else if($page=="detil_peserta") {
	include "../peserta/$page.php";
	}
	//======== akhir menu peserta ================
	
	//menu lembaga
	else if($page=="lembaga") {
	include "../lembaga/lihat_lembaga.php";
	} else if($page=="input_lembaga") {
	include "../lembaga/$page.php";
	} else if($page=="act_input_lembaga") {
	include "../lembaga/$page.php";
	} else if($page=="edit_lembaga") {
	include "../lembaga/$page.php";
	} else if($page=="act_edit_lembaga") {
	include "../lembaga/$page.php";
	} else if($page=="act_hapus_lembaga") {
	include "../lembaga/$page.php";
	} else if($page=="detil_lembaga") {
	include "../lembaga/$page.php";
	
	//======== akhir menu lembaga ================

	
	
	//menu user
	} else if($page=="user") {
	include "../user/lihat_user.php";
	} else if($page=="input_user") {
	include "../user/$page.php";
	} else if($page=="act_input_user") {
	include "../user/$page.php";
	} else if($page=="edit_user") {
	include "../user/$page.php";
	} else if($page=="act_edit_user") {
	include "../user/$page.php";
	} else if($page=="act_hapus_user") {
	include "../user/$page.php";
	}
	//==========  akhir menu user  =================
	
	//menu ultilty
	else if($page=="utility") {
	include "../utility/link.php";
	} else if($page=="backup") {
	include "../utility/$page.php";
	}
	//========== akhir menu utility ===============
	
	//log out	
	else if($page=="logout") {
	logout();
	} else {
	echo $utama;
	}
	?>
	</div>
	</td><tr>
	<td colspan="2" style="border-top: solid 2px #f9f9f9; font-size: 12px" align="center">&copy; copyright : Dinsosnakertrans Kota Surakarta &nbsp;<br>All Right Reserved</td>
	
	</tr>
</table>
<?php
//}
?>
<html>
<head>
<title>.:: Sistem Informasi Peserta Pelatihan Dinsosnakertrans Kota Surakarta ::.</title>

</head>

<body>
<center>
<table border=0 width="900px" height="630px" background=image/halaman_utama.jpg>
	<tr>
	<form action="login.php" name="login" method="post">
		<td style="padding: 8px 0 8px 0" align="center">
		Username : <input type="text" name="user"  required> Password : <input type="password" name="pass" required><input type="submit" value="log in">
		</td>
	</form>
	</tr>
	
</table>
</center>
</body>
</html>
<?php
include "../penempatan/link.php";
?>

<form method="post" action="?page=act_input_penempatan">
<table border=1 width=100% class="table-data">
<tr><td class="head-data" colspan="2">Penempatan Peserta Pelatihan</td></tr>
<tr>
	<td class="pinggir-data">Tahun Anggaran</td>
	<td class="pinggir-data">
		<select name="ta">
			<option value="" selected>-------Pilih Tahun Anggaran-------</option>
			<?php
				include "../include/koneksi_db.php";
				$t=mysql_query("SELECT distinct ta FROM peserta order by ta", $konek);
				while ($peserta=mysql_fetch_array($t)){
					echo "<option value='$peserta[ta]'>$peserta[ta]</option>";
				}
			?>
		</select>
	</td>
</tr>
<tr>
	<td class="pinggir-data">Kejuruan</td>
	<td class="pinggir-data">
		<select name="kejuruan">
			<option value="" selected>-------Pilih Kejuruan-------</option>
			<?php
				include "../include/koneksi_db.php";
				$k=mysql_query("SELECT distinct kejuruan FROM peserta ORDER by kejuruan", $konek);
				while ($peserta=mysql_fetch_array($k)){
					echo "<option value='$peserta[kejuruan]'>$peserta[kejuruan]</option>";
				}
			?>
		</select>
	</td>
</tr>
<tr><td class="pinggir-data">Nama Peserta</td>
<td class="pinggir-data">
<select name="peserta">
<option value="" selected>------- Pilih Nama Peserta -----</option>
<?php
include "../include/koneksi_db.php";
$q=mysql_query("SELECT * FROM peserta", $konek);
while ($peserta=mysql_fetch_array($q)) {
echo "<option value='$peserta[nama]'>$peserta[nama]</option>";
}
?>
</select> <a href="?page=input_peserta">Tambah Peserta Baru</a>
</td></tr>

<tr><td class="pinggir-data">Lembaga Pelaksana</td>
<td class="pinggir-data">
<select name="lembaga">
<option value="" selected>------- Pilih Lembaga Pelaksana -----</option>
<?php
$qa=mysql_query("SELECT * FROM lembaga", $konek);
while ($lembaga=mysql_fetch_array($qa)) {
echo "<option value='$lembaga[nama]'>$lembaga[nama]</option>";
}
?>
</select>
</td></tr>

<tr><td class="pinggir-data">Sertifikasi</td><td class="pinggir-data"><input type="text" name="sertifikasi" size="40"></td></tr>
<tr><td class="pinggir-data">Penempatan</td><td class="pinggir-data"><input type="text" name="k_penempatan" size="40"></td></tr>
<tr><td class="pinggir-data">Alamat Perusahaan</td><td class="pinggir-data"><input type="text" name="t_penempatan" size="40"></td></tr>

<tr><td class="pinggir-data">Keterangan</td>
<td class="pinggir-data"><input type="text" name="ket" size="40"></td></tr>

<tr><td colspan="2" align="center" class="head-data">
<input type="submit" value="Input">
</td></tr>
</table>
</form>

<?php
include "../include/koneksi_db.php";
include "../penempatan/link.php";

$id		= isset($_GET['id']) ? $_GET['id'] : "";

if ($id == "") {
	echo "<script>alert('Pilih dulu data yang akan di-update');</script>";
	echo "<meta http-equiv='refresh' content='0; url=lihat_penempatan.php'>";
} else {
	$query			= mysql_query("SELECT * FROM penempatan WHERE id=$id", $konek);
	$hasil			= mysql_fetch_array($query);
	$id				= $hasil['id'];
	$tahun 			= $hasil['tahun'];
	$kejuruan		= $hasil['kejuruan'];
	$nama_peserta	= $hasil['nama_peserta'];
	$lembaga		= $hasil['lembaga'];
	$sertifikasi	= $hasil['sertifikasi'];
	$k_penempatan	= $hasil['k_penempatan'];
	$t_penempatan	= $hasil['t_penempatan'];
	$ket			= $hasil['ket'];

}
?>

<form method="post" action="?page=act_edit_penempatan">
<table width=100% border=1 class="table-data">
<input type="hidden" name="id" value="<?php echo $id; ?>">
<tr><td class="head-data" colspan="2">Edit Data Penempatan : <?php echo $nama_peserta; ?></td></tr>
<tr><td class="pinggir-data">Tahun Anggaran</td>
<td class="pinggir-data"><input type="text" size="65" name="tahun" value="<?php echo $tahun; ?>"></td></tr>
<tr><td class="pinggir-data">Kejuruan</td>
<td class="pinggir-data"><input type="text" size="65" name="kejuruan" value="<?php echo $kejuruan; ?>"></td></tr>
<tr><td class="pinggir-data">Nama Alumni</td>
<td class="pinggir-data"><input type="text"  size="65" name="nama_peserta" value="<?php echo $nama_peserta; ?>"></td></tr>
<tr><td class="pinggir-data">Lembaga Pelaksana</td>
<td class="pinggir-data"><input type="text" size="15"name="lembaga" value="<?php echo $lembaga; ?>"></td></tr>
<tr><td class="pinggir-data">Sertifikasi</td>
<td class="pinggir-data"><input type="text" size="65" name="sertifikasi" value="<?php echo $sertifikasi; ?>"></td></tr>
<tr><td class="pinggir-data">Penempatan</td>
<td class="pinggir-data"><input type="text" size="65" name="k_penempatan" value="<?php echo $k_penempatan; ?>"></td></tr>
<tr><td class="pinggir-data">Alamat Perusahaan</td>
<td class="pinggir-data"><input type="text" size="25" name="t_penempatan" value="<?php echo $t_penempatan; ?>"></td></tr>
<tr><td class="pinggir-data">Keterangan</td>
<td class="pinggir-data"><input type="text" size="25"name="ket" value="<?php echo $ket; ?>"></td></tr>
<tr><td class="head-data" colspan="2" align="center">
<input type="submit" value="Update">
</td></tr>
</table>
</form>
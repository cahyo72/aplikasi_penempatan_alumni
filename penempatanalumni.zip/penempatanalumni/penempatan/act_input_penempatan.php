<?php


$tahun			= isset($_POST['ta']) ? $_POST['ta'] : "";
$nama_peserta	= isset($_POST['peserta']) ? $_POST['peserta'] : "";
$kejuruan		= isset($_POST['kejuruan']) ? $_POST['kejuruan'] : "";
$lembaga		= isset($_POST['lembaga']) ? $_POST['lembaga'] : "";
$sertifikasi	= isset($_POST['sertifikasi']) ? $_POST['sertifikasi'] : "";
$k_penempatan	= isset($_POST['k_penempatan']) ? $_POST['k_penempatan'] : "";
$t_penempatan	= isset($_POST['t_penempatan']) ? $_POST['t_penempatan'] : "";
$ket			= isset($_POST['ket']) ? $_POST['ket'] : "";


if($nama_peserta == "") {
	echo "<script>alert('Pilih dulu Nama Peserta!!');</script>";
	echo "<meta http-equiv='refresh' content='0; url=?page=input_penempatan'>";
} elseif ($lembaga=="") {
	echo "<script>alert('Pilih dulu Lembaga Pelaksana-Nya!!');</script>";
	echo "<meta http-equiv='refresh' content='0; url=?page=input_penempatan'>";
} else {
	include "../include/koneksi_db.php";

	$qt	= mysql_query("INSERT INTO penempatan VALUES (NULL, '$tahun', '$nama_peserta', '$kejuruan', '$lembaga', '$sertifikasi', '$k_penempatan','$t_penempatan', '$ket')", $konek) or die ("Gagal Masuk ".mysql_error());

	}
if ($qt) {
			echo "<script>alert('Data berhasil ditambahkan @ $hari_ini. Terima Kasih')</script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=penempatan'>";
		} else {
			echo "<script>alert('Data anda gagal dimasukkan karena. Ulangi sekali lagi')</script>";
			echo mysql_error();
			//echo "<meta http-equiv='refresh' content='0; url=?page=input_penempatan'>";
		}
?>

<?php

include "../include/koneksi_db.php"; //memanggil file koneksi_db.php
include "../penempatan/link.php";
include "../include/config.php";


//tampilkan form pencarian
echo "<center><form action='' method='post'><input type='text' name='cari' value='Pencarian...' onfocus=\"this.value='';\" onblur=\"if(this.value=='') this.value='Pencarian...';\">&nbsp;&nbsp;<input type='submit' value='go' name='go'>&nbsp;&nbsp;&nbsp;*) masukkan nama alumni</form></scenter>";

//variabel _GET /
$hal	= isset($_GET['hal']) ? $_GET['hal'] : "";


//variabel _POST 
$cari	= isset($_POST['cari']) ? $_POST['cari'] : "";
$go		= isset($_POST['go']) ? $_POST['go'] : "";


$per_halaman	= 20;   // jumlah record data per halaman

if ($hal==""||$hal==1) {
	$awal=0;
} else {
	$awal=($hal*$per_halaman)-$per_halaman;
}
$batas=$per_halaman;

if ($go == "go" && $cari != "Pencarian...") {
	$query		= mysql_query("SELECT * FROM penempatan WHERE kejuruan LIKE '%$cari%' OR nama_peserta LIKE '%$cari%' OR tahun LIKE '%$cari%'", $konek);
	$j_cari		= mysql_num_rows($query);
	$jm_cari	= ceil($j_cari/$per_halaman);
} else if ($go == "" || $cari == "Pencarian...") {
	$query		=mysql_query("SELECT * FROM penempatan ORDER BY id LIMIT $awal,$batas", $konek);
	$j_cari		= mysql_num_rows($query);
	$jm_cari	= ceil($j_cari/$per_halaman);
}



$query2=mysql_query("SELECT * FROM penempatan ORDER BY id", $konek);
$jumlah_penempatan=mysql_num_rows($query2);
$jum_halaman=ceil($jumlah_penempatan/$per_halaman);
//echo $jum_halaman;


if ($jum_halaman==1) { // ||$jm_cari<=10
echo "";
} else {
echo "<center><font size='3px'>Halaman : </font>";
for ($i=1; $i<=$jum_halaman; $i++) {
	if ($i==$hal) {
	echo "<font size='4px' color='green'>[<a href='?page=penempatan&hal=$i'><b>$i</b></a>]</font>";
	} else {
	echo "<font size='2px' color='red'>[<a href='?page=penempatan&hal=$i'><b>$i</b></a>]</font>";
	}
}
echo "</center><hr>";
}
?>
<table border="1" width=100% class="table-data">
<tr><td class="head-data">No</td><td class="head-data">Nama Peserta</td><td class="head-data">Kejuruan</td><td class="head-data">Lembaga Pelaksana</td><td class="head-data">Sertifikasi</td><td class="head-data">Penempatan<td class="head-data">Alamat Perusahaan</td><td class="head-data">Tahun</td><td class="head-data">Keterangan</td><td class="head-data">Edit</td><td class="head-data">Hapus</td></tr>
<?php
$no=0;
while ($hasil=mysql_fetch_array($query)) {
$no++;
echo "<tr>
	  <td class='td-data'>$no</td>
      <td class='pinggir-data'>$hasil[nama_peserta]</td>
	  <td class='td-data'>$hasil[kejuruan]</td>
	  <td class='td-data'>$hasil[lembaga]</td>
	  <td class='td-data'>$hasil[sertifikasi]</td>
	  <td class='td-data'>$hasil[k_penempatan]</td>
	  <td class='td-data'>$hasil[t_penempatan]</td>
	  <td class='td-data'>$hasil[tahun]</td>
	  <td class='td-data'>$hasil[ket]</td>
	  <td class='td-data'><a href='?page=edit_penempatan&id=$hasil[id]'><img class='img_link' src='../image/edit.png' width='15px' height='15px'></a></td>
	  <td class='td-data'><a href='?page=act_hapus_penempatan&id=$hasil[id]' onclick='return confirm(\"Anda yakin ingin menghapus data penempatan $hasil[nama_peserta] ?\")'><img class='img_link' src='../image/delete.png' width='15px' height='15px'></a></td></tr>";

}
?>
</table>

<center>
	<form action='' method='post'>
		<font size='3px'>Jurusan : </font>
		<select name="jurusan">
			<option value="Desain">Desain Grafis</option>
			<option value="Menjahit">Menjahit</option>
			<option value="Pramuniaga">Pramuniaga</option>
			<option value="Terapi">Terapi Refleksologi</option>
			<option value="Otomotif">Otomotif</option>
		</select>
		&nbsp;&nbsp;<input type='submit' value='Cetak' name='cetak'>
	</form>
</center>
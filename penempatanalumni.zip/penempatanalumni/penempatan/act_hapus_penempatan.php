<?php
include "../include/koneksi_db.php"; //memanggil file koneksi_db.php


$id		= isset($_GET['id']) ? $_GET['id'] : "";


if ($id=="") {
	echo "<script>alert('Pilih dulu data yang akan di-hapus');</script>";
	echo "<meta http-equiv='refresh' content='0; url=?page=penempatan'>";
} else {
	$query = mysql_query("DELETE FROM penempatan WHERE id='$id'", $konek);

	if ($query) {
		echo "<script>alert('Data berhasil dihapus')</script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=penempatan'>";
	} else {
		echo "Data anda gagal dihapus. Ulangi sekali lagi";
		echo "<meta http-equiv='refresh' content='0; url=?page=penempatan'>";
	}
}
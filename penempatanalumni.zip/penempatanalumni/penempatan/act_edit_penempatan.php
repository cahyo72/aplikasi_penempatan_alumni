<?php
include "../include/koneksi_db.php"; //memanggil file koneksi_db.php
include "../include/fungsi2.php"; //memanggil file fungsi.php

//variabel _POST
$id		 	 	= isset($_POST['id']) ? addslashes($_POST['id']) : "";
$tahun     		= isset($_POST['tahun']) ? addslashes($_POST['tahun']) : "";
$kejuruan  		= isset($_POST['kejuruan']) ? addslashes($_POST['kejuruan']) : "";
$nama_peserta	= isset($_POST['nama_peserta']) ? addslashes($_POST['nama_peserta']) : "";
$lembaga	   	= isset($_POST['lembaga']) ? addslashes($_POST['lembaga']) : "";
$sertifikasi  	= isset($_POST['sertifikasi']) ? addslashes($_POST['sertifikasi']) : "";
$k_penempatan	= isset($_POST['k_penempatan']) ? addslashes($_POST['k_penempatan']) : "";
$t_penempatan	= isset($_POST['t_penempatan']) ? addslashes($_POST['t_penempatan']) : "";
$ket	 		= isset($_POST['ket']) ? addslashes($_POST['ket']) : "";


if ($id == "") {
	echo "<script>alert('Pilih dulu data yang akan di-update');</script>";
	echo "<meta http-equiv='refresh' content='0; url=?page=penempatan'>";
} else {
	$query = mysql_query("UPDATE penempatan SET tahun='$tahun', nama_peserta='$nama_peserta', kejuruan='$kejuruan', lembaga='$lembaga', sertifikasi='$sertifikasi', k_penempatan='$k_penempatan', t_penempatan='$t_penempatan', ket='$ket' WHERE id='$id'", $konek);

	if ($query) {
		echo "<script>alert('Data berhasil diupdate @ $hari_ini.Terima Kasih')</script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=penempatan'>";
	} else {
		Echo "Data anda gagal diupdate. Ulangi sekali lagi".mysql_error();
		echo "<meta http-equiv='refresh' content='0; url=?page=edit_penemptan&id=$id'>";
	}
}
?>

<?php

$dapat	= isset($_POST['peserta']) ? $_POST['peserta'] : "";
$pecah	= explode (".", $dapat);
$nama_peserta	= $pecah[0];
$alamat_peserta	= $pecah[1];
$kejuruan		= $pecah[2];
$lembaga		= isset($_POST['lembaga']) ? $_POST['lembaga'] : "";
$sertifikasi	= isset($_POST['sertifikasi']) ? $_POST['sertifikasi'] : "";
$k_penempatan	= isset($_POST['k_penempatan']) ? $_POST['k_penempatan'] : "";
$t_penempatan	= isset($_POST['t_penempatan']) ? $_POST['t_penempatan'] : "";
$tahun			= isset($_POST['tahun']) ? $_POST['tahun'] : "";
$ket			= isset($_POST['ket']) ? $_POST['ket'] : "";


if($nama_peserta == "" || $dapat == "") {
	echo "<script>alert('Pilih dulu Nama Peserta!!');</script>";
	echo "<meta http-equiv='refresh' content='0; url=?page=input_penempatan'>";
} elseif ($lembaga=="") {
	echo "<script>alert('Pilih dulu Lembaga Pelaksana-Nya!!');</script>";
	echo "<meta http-equiv='refresh' content='0; url=?page=input_penempatan'>";
} else {
	include "../include/koneksi_db.php";

	$qt	= mysql_query("INSERT INTO penempatan VALUES (null, '$nama_peserta', '$alamat_peserta', '$kejuruan', '$lembaga', '$sertifikasi', '$k_penempatan',$t_penempatan', $tahun','$ket')", $konek) or die ("Gagal Masuk ".mysql_error());

	}

?>

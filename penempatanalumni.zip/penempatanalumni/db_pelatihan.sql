-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 20, 2016 at 09:28 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_pelatihan`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
`id` int(2) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'lattas');

-- --------------------------------------------------------

--
-- Table structure for table `kejuruan`
--

CREATE TABLE IF NOT EXISTS `kejuruan` (
  `id` int(2) NOT NULL,
  `kejuruan` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lembaga`
--

CREATE TABLE IF NOT EXISTS `lembaga` (
`id` int(2) NOT NULL,
  `nama` varchar(25) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `telp` varchar(25) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lembaga`
--

INSERT INTO `lembaga` (`id`, `nama`, `alamat`, `telp`) VALUES
(6, 'AFISTA HUSADA', 'Jl. KH Agus Salim No. 43 Sondakan Laweyan Surakart', '726673 / 5816559'),
(7, 'ANDROMEDA SLAMET RIYADI C', 'Jl. Sumpah Pemuda No. 18 Kadipiro Banjarsari Surak', '9116336 / 0817442458'),
(8, 'ARINDWITA', 'Jl. Monginsidi No 35 Surakarta', '08156737867'),
(9, 'BINA AVIA PERSADA', 'Jl. Slamet Riyadi 286 Surakarta', '719993'),
(10, 'BINA INSANI', 'Jl. Sri Narendro No. 2 Baron Gede Surakarta', '716588'),
(11, 'BHAKTI INSAN ABADI', 'Jl. Mangga IV Jajar Laweyan', '710614'),
(12, 'BINTANG DARMA INTAMA', 'Jl. Gunung Slamet No. 107 Sukorejo Kadipiro Banjar', '8501387 / 3081414'),
(13, 'BHAKTI KENCANA', 'Jl. Adi Sumarmo No. 18 Banyuanyar Surakarta', '734149'),
(14, 'CIPTO BHAKTI HUSODO', 'Jl. Flores No. 12 Kp. Baru Surakarta', '630331'),
(15, 'CAKRA', 'Jl. Kahuripan Utara No. 7 Rt 04/06 Sumber Banjarsa', '712354'),
(16, 'DIAN NUSANTARA', 'Jl. Dr. Wahidin No. 6 A Surakarta', '717761'),
(17, 'GAJAH MADA BARU', 'Jl. Hasanudin No. 139 Punggawan Banjarsari Surakar', '0816674239'),
(18, 'INLASTEK SURAKARTA', 'Jl. Joko Tingkir No. 5 Pajang Surakarta', '732339 / 737228'),
(19, 'INTERNATIONAL CRUISESHIPS', 'Jl. A Yani No. 393 Rt. 04/3 Kerten Surakarta', '728300'),
(20, 'ISTIBANK', 'Jl. Ir. Sutami No 46 Sekarpace Jebres Surakarta', '630029'),
(21, 'KAMSAHAMNIDA', 'Jl. Kyai Mojo Rt. 04/05 Semanggi Surakarta', '081393000418'),
(22, 'MARANATHA', 'Jl. Nakula 28 B Makam Bergolo Serengan Surakarta', '639301'),
(23, 'NUSA HUSADA Medicare', 'Jl. KH. Samanhudi 31 Mangkuyudan Surakarta', '655857'),
(24, 'NAKAMURA', 'Jl. Jageran No. 10 C Ketelan Surakarta', '630252 / 645587'),
(25, 'NAKAYOSI', 'Jl. Kedung Tungkul Rt 03/07 Mojosongo Jebres Surak', '085702536785 / 0821347055'),
(26, 'PUTRI MANDIRI', 'Jl. Nias II No. 23 Bibis Kulon Surakarta', '651015'),
(27, 'PERMATA ILMU SURAKARTA', 'Bibis Luhur Rt 01/21 Nusukan Banjarsari Surakarta', '08510700845'),
(28, 'PINK PRODUCTION ', 'Jl. Kalingg Tengah II Villa Pandawa Banyuwangi No.', '2135101'),
(29, 'RAJAWALI AVIATION TRAININ', 'Jl. Slamet Riyadi 335 (Riyadi Palace Hotel) Suraka', '7567533'),
(30, 'ROYAL SEASONS HOTEL EDUCA', 'Jl. Ahmad Yani No. 40 Surakarta', '731312'),
(31, 'SALWA TRAINING CENTRE', 'Jl. Surya No. 158 Jagalan Surakarta', '656622'),
(32, 'SOLOCOM', 'Jl. Ir Sutami No. 25 Surakarta', '645054 / 653986'),
(33, 'SBRI AMAL PRAWIRA', 'Ruko Manahan Blok F Jl. Adi Sucipto Surakarta', '727792 / 727797'),
(34, 'SUBASA', 'Jl. RM Said No. 199 Surakarta', '2701005/ 081227110005'),
(35, 'SEKAR SARI', 'Jl. Adi Sumarmo No. 91 Nusukan Surakarta', '718524 / 08156738707'),
(36, 'TISSA', 'Jl. Gelatik No. IV / 3 Manahan Surakarta', '714328'),
(37, 'TRANS AVIA AIRLINES & CRU', 'Jl. Truntum 2 No. 2 Jantirejo Sondakan Surakarta', '740235'),
(38, 'UNIBA', 'Jl. Tiga Negeri No. 144 Laweyan Surakarta', '714751'),
(39, 'YOGA MUSTIKA PERSADA', 'Jl. Menteri Supeno No. 7 B Manahan Surakarta', '712698'),
(40, 'YPAB PERMATA HATI', 'Jl. Pracanda Rt 01/33 Jebres Surakarta', '632456'),
(41, 'YUKIMAGA ABADI', 'Jl. Gunung Slamet No. 105 Sukorejo Rt 06/30 Kadipi', '082221909747'),
(44, 'SALA LABORATORY OF ENGLIS', 'Jl. Perintis Kemerdekaan No. 7 Surakarta', '716720'),
(45, 'MAGISTRA UTAMA', 'Jl. KH. Samanhudi 148 Surakarta', '713971'),
(46, 'VICTORIA HOTEL SCHOOL', 'Ruko Honggowongso Square Jl. Honggowongso No. 57 P', '081329141351');

-- --------------------------------------------------------

--
-- Table structure for table `penempatan`
--

CREATE TABLE IF NOT EXISTS `penempatan` (
`id` int(3) NOT NULL,
  `tahun` varchar(4) NOT NULL,
  `nama_peserta` varchar(100) NOT NULL,
  `kejuruan` varchar(20) DEFAULT NULL,
  `lembaga` varchar(30) DEFAULT NULL,
  `sertifikasi` varchar(10) DEFAULT NULL,
  `k_penempatan` varchar(50) DEFAULT NULL,
  `t_penempatan` varchar(50) DEFAULT NULL,
  `ket` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penempatan`
--

INSERT INTO `penempatan` (`id`, `tahun`, `nama_peserta`, `kejuruan`, `lembaga`, `sertifikasi`, `k_penempatan`, `t_penempatan`, `ket`) VALUES
(1, '2015', 'ANDREW WIRASANJAYA P', 'OTOMOTIF', 'Magistra Utama', 'Tidak', 'Angkatan', 'Jl. Kepel Timur 2 Rt 1/1 Karangasem Laweyan Suraka', ''),
(2, '2015', 'ARDIANSYAH TEJA MUKTIARA', 'OTOMOTIF', 'Magistra Utama', 'Tidak', 'Toko Tangguh', 'Nayu, Nusukan, Ska', ''),
(3, '2015', 'AGUNG PRIYAMBODO', 'OTOMOTIF', 'Magistra Utama', 'Tidak', 'PT. CITRA WARNA', 'Pucang sawit Rt 1/11 Jebres Surakarta', ''),
(4, '2015', 'ANGGI DAVIYARTO', 'OTOMOTIF', 'Magistra Utama', 'Tidak', 'PT. Tunas Jaya Motor', 'Jl. Kyai Mojo Mojolaban', ''),
(5, '2015', 'ARRIZAL NOOR HERMANSYAH', 'OTOMOTIF', 'Magistra Utama', 'Tidak', 'PT. RAMAYANA MOTOR', 'JL. Ir. SUTAMI JEBRES SURAKARTA', ''),
(6, '2015', 'ADHI PAMUNGKAS', 'OTOMOTIF', 'Magistra Utama', 'Tidak', 'PT. Harpindo Jaya Motor', 'Jl. Piere Tendean Nusukan', ''),
(7, '2015', 'ARROFI YUDHA SAKTI', 'OTOMOTIF', 'Magistra Utama', 'Tidak', 'PT. Panggung Motor', 'Jl. Piere Tendean Nusukan', ''),
(8, '2015', 'DANI BAGUS RAHMADI', 'OTOMOTIF', 'Magistra Utama', 'Tidak', 'Electronic Solution Solo Grand Mall', 'Jl. Slamet Riyadi Surakarta', ''),
(9, '2015', 'DEDY ISWANTO', 'OTOMOTIF', 'Magistra Utama', 'Tidak', 'Proses', '', ''),
(10, '2015', 'DWI PURWOKO', 'OTOMOTIF', 'Magistra Utama', 'Tidak', 'AHASS NGUDI LUHUR', 'Jl Kyai Mojo Semanggi Surakarta', ''),
(11, '2015', 'ESADULLAH AHMAD YENSA', 'OTOMOTIF', 'Magistra Utama', 'Tidak', 'PT. CENTRAL SAKTI MOTOR', 'Jl. Piere Tendean Nusukan Surakarta', ''),
(12, '2015', 'FAJAR ADI JATMIKO', 'OTOMOTIF', 'Magistra Utama', 'Tidak', 'Proses', '', ''),
(13, '2015', 'NUR UTOMO BAYU AJI', 'OTOMOTIF', 'Magistra Utama', 'Tidak', 'MELANJUTKAN SEKOLAH', '', ''),
(14, '2015', 'RIZQI TRI ARYADI', 'OTOMOTIF', 'Magistra Utama', 'Tidak', 'Proses', '', ''),
(15, '2015', 'RADITYA SETYAWAN', 'OTOMOTIF', 'Magistra Utama', 'Tidak', 'PT. HARPINDO JAYA MOTOR', 'Jl. Slamet Riyadi Purwosari Surakarta', ''),
(16, '2015', 'ROLEX ROSINDA', 'OTOMOTIF', 'Magistra Utama', 'Tidak', 'Ahass Ngudi Luhur', 'Jl. Kyai Mojo Semanggi Surakarta', ''),
(17, '2015', 'RIDHO MARHENDRA', 'OTOMOTIF', 'Magistra Utama', 'Tidak', 'Proses', '', ''),
(18, '2015', 'VINCENT ADITYA PRASETYA', 'OTOMOTIF', 'Magistra Utama', 'Tidak', 'PT. DETA MOTOR', 'Jl. Adi Sucipto Surakarta', ''),
(19, '2015', 'WITANTO', 'OTOMOTIF', 'Magistra Utama', 'Tidak', 'Proses', '', ''),
(20, '2015', 'FEBRI PURWANTO', 'OTOMOTIF', 'Magistra Utama', 'Tidak', 'PT. RAMAYANA MOTOR', 'JL. Ir. SUTAMI JEBRES SURAKARTA', '-'),
(21, '2015', 'ANIK SUSILOWATI', 'Menjahit', 'Bhakti Kencana', 'Tidak', 'WIRAUSAHA', '', ''),
(22, '2015', 'AMINUDIN', 'Menjahit', 'Bhakti Kencana', 'Tidak', 'KONVEKSI BATIK PAPUA', 'Baki Sukoharjo', ''),
(23, '2015', 'CAHYANI ENDRI S', 'Menjahit', 'Bhakti Kencana', 'Tidak', 'Konveksi Lila Lina ', 'Kampung Belukan Rt 4/4 Pajang Laweyan', ''),
(24, '2015', 'CAHYANI PURNAMASARI', 'Menjahit', 'Bhakti Kencana', 'Tidak', 'KONVEKSI MATAHARI', 'Jl. Tri Busono Mutihan Surakarta', ''),
(25, '2015', 'CUT HANY SORAYA', 'Menjahit', 'Bhakti Kencana', 'Tidak', 'WIRAUSAHA(MODISTE HANY)', '', ''),
(26, '2015', 'ERNI SISI LASMANY', 'Menjahit', 'Bhakti Kencana', 'Tidak', 'WIRAUSAHA(MODISTE SUSI)', '', ''),
(27, '2015', 'EFNI RATNAWATI A', 'Menjahit', 'Bhakti Kencana', 'Tidak', 'Penjahit Bu Luwis ', 'Aspol Manahan Rt 4/12', ''),
(28, '2015', 'ENDANG MULYANI, SE', 'Menjahit', 'Bhakti Kencana', 'Tidak', 'JEANNY COLLECTION', 'Mutihan Rt 2/X Laweyan Surakarta', ''),
(29, '2015', 'FATIMAH DWI FAUZIAH', 'Menjahit', 'Bhakti Kencana', 'Tidak', 'PENJAHIT KENCANA', 'Jl. Adi Sumarmo No. 18 Banyuanyar', ''),
(30, '2015', 'KUMPUL BARWANTO', 'Menjahit', 'Bhakti Kencana', 'Tidak', 'WIRAUSAHA ( ART GASARA )', '', ''),
(31, '2015', 'KRISTANTI', 'Menjahit', 'Bhakti Kencana', 'Tidak', 'Melanjutkan Sekolah', '', ''),
(32, '2015', 'NIKEN LARAS ASRI', 'Menjahit', 'Bhakti Kencana', 'Tidak', 'WIRAUSAHA ( MODISTE NIKEN )', '', ''),
(33, '2015', 'RIRIN LISTYANINGRUM', 'Menjahit', 'Bhakti Kencana', 'Tidak', 'WIRAUSAHA ( HIJAB ALISHA )', '', ''),
(34, '2015', 'SITI ANIK NURUL CHASANAH', 'Menjahit', 'Bhakti Kencana', 'Tidak', 'WIRAUSAHA ( FINA COLLECTION )', '', ''),
(35, '2015', 'SRIWIJAYA PURBA H', 'Menjahit', 'Bhakti Kencana', 'Tidak', 'WIRAUSAHA', '', ''),
(36, '2015', 'SRI LESTARI', 'Menjahit', 'Bhakti Kencana', 'Tidak', 'KONVEKSI MATAHARI', 'Jl. Tri Busono Mutihan Surakarta', ''),
(37, '2015', 'TIN BINTARI', 'Menjahit', 'Bhakti Kencana', 'Tidak', 'BUTIK MY TAILOR & BOUTIQUE', 'Perum Purbayan No. 14 Gentan', ''),
(38, '2015', 'WENY PUJIASTUTI', 'Menjahit', 'Bhakti Kencana', 'Tidak', 'Penjahit Kencana', 'Jl. Adi Sumarmo No. 18 Banyuanyar', ''),
(39, '2015', 'YOHANA FRANCISKA DIAN R', 'Menjahit', 'Bhakti Kencana', 'Tidak', 'Melanjutkan Sekolah', '', ''),
(40, '2015', 'ZULFA NURHAYATI', 'Menjahit', 'Bhakti Kencana', 'Tidak', 'KONVEKSI BATIK PAPUA', 'Baki Sukoharjo', ''),
(41, '2015', 'ANDRIAN KRISNAMURTI D', 'Desain Grafis', 'Dian Nusantara Surak', 'Tidak', 'SD Pangudi Luhur Surakarta', 'Jl. Kebalen Surakarta', ''),
(42, '2015', 'ANDIKA RIZAL H', 'Desain Grafis', 'Dian Nusantara Surak', 'Tidak', 'PROSES', '', ''),
(43, '2015', 'APRILIA HANA CHRISTIANA', 'Desain Grafis', 'Dian Nusantara Surak', 'Tidak', 'LKP PERMATA ILMU', 'Bibis Mojosongo Surakarta', ''),
(44, '2015', 'CHRISTIANTO WIBOWO', 'Desain Grafis', 'Dian Nusantara Surak', 'Tidak', 'Indomaret', 'Jl. KH. Agus Salim Laweyan Surakarta', ''),
(45, '2015', 'DWI KUNCORO HADI', 'Desain Grafis', 'Dian Nusantara Surak', 'Tidak', 'PROSES', '', ''),
(46, '2015', 'DEWI PRASETYOWATI', 'Desain Grafis', 'Dian Nusantara Surak', 'Tidak', 'WIRAUSAHA ( HERBALIFE )', 'Jl. Seruni 2 No. 19 Mangkubumen Banjarsari Surakar', ''),
(47, '2015', 'DIAH PERMATA DEWI Y', 'Desain Grafis', 'Dian Nusantara Surak', 'Tidak', 'GARASI DIGITAL PRINTING', '', ''),
(48, '2015', 'DIAN CANDRA S', 'Desain Grafis', 'Dian Nusantara Surak', 'Tidak', 'WIRAUSAHA', '', ''),
(49, '2015', 'DWI RIZKY FAUZIAH', 'Desain Grafis', 'Dian Nusantara Surak', 'Tidak', 'Foodcourt Solo Grand Mall', 'Jl. Slamet Riyadi Surakarta', ''),
(50, '2015', 'DIAN CAHYA CINTAMI', 'Desain Grafis', 'Dian Nusantara Surak', 'Tidak', 'WIRAUSAHA (GROSIR MUKENA)', 'Jl. Semanggi Rt  01/16 Semanggi Pasar Kliwon Surak', ''),
(51, '2015', 'DIMAS SAPUTRO', 'Desain Grafis', 'Dian Nusantara Surak', 'Tidak', 'GARASI DIGITAL PRINTING', 'Jl. A. Yani No 213 Gilingan Banjarsari Surakarta', ''),
(52, '2015', 'FARIZ I BAHTIAR', 'Desain Grafis', 'Dian Nusantara Surak', 'Tidak', 'PT. GRAHA FARMA', 'Jl. Solo Sragen', ''),
(53, '2015', 'GARENDHI KUKUH', 'Desain Grafis', 'Dian Nusantara Surak', 'Tidak', 'PROSES', '', ''),
(54, '2015', 'HARI RHOMADHONY AWAN', 'Desain Grafis', 'Dian Nusantara Surak', 'Tidak', 'WIRAUSAHA ( PEMBUATAN SANGKAR BURUNG)', 'Dipotrunan Rt. 01/12 Tipes Serengan Surakarta', ''),
(55, '2015', 'KADARSIH ESTI', 'Desain Grafis', 'Dian Nusantara Surak', 'Tidak', 'BARON PUTRA ADVERTISING', 'Jl. DR. Radjiman Surakarta(Depan Hotel Baron)', ''),
(56, '2015', 'NURAENI TRISNAWATI', 'Desain Grafis', 'Dian Nusantara Surak', 'Tidak', 'KOPERASI UNS', 'Jl. Ir Sutami Kentingan Surakarta', ''),
(57, '2015', 'RONI MUSTOFA', 'Desain Grafis', 'Dian Nusantara Surak', 'Tidak', 'WIRAUSAHA', '', ''),
(58, '2015', 'TETUKO BAYU AJI', 'Menjahit', 'Dian Nusantara Surak', 'Tidak', 'BATIK KAHURIPAN SURKARTA', 'Jl. Kahuripan Utara Raya No. 12 Sumber, Banjarsari', ''),
(59, '2015', 'WINDITYAS F N', 'Desain Grafis', 'Dian Nusantara Surak', 'Tidak', 'PT. SINARMAS DISTRIBUSI NUSANTARA', 'Jl. Dagen Jaten Karanganyar', ''),
(60, '2015', 'ZIANA YULIANTI', 'Desain Grafis', 'Dian Nusantara Surak', 'Tidak', 'PT. TAKETAMA PERDANA SUKOHARJO', 'Jl. WR. Supratman No. 181, Baki, Sukoharjo', ''),
(61, '2014', 'AANG KHUNAIFI ULINUHA', 'Pramuniaga', '', 'Tidak', 'PT. Smart THR Sriwedari Surakarta', 'Jl. Slamet Riyadi Surakarta', ''),
(62, '2014', 'ANGGARA RETNA PALUPI', 'Pramuniaga', '', 'Tidak', 'PT. Smart THR Sriwedari Surakarta', 'Jl. Slamet Riyadi Surakarta', ''),
(63, '2014', 'DEVINTA LUSI LUFIKASARI', 'Pramuniaga', '', 'Tidak', 'PT. Smart THR Sriwedari Surakarta', 'Jl. Slamet Riyadi Surakarta', ''),
(64, '2014', 'HAFIDHZYAN MALIK', 'Pramuniaga', '', 'Tidak', 'PT. Smart THR Sriwedari Surakarta', 'Jl. Slamet Riyadi Surakarta', ''),
(65, '2014', 'HERI KURNIYAWAN', 'Pramuniaga', '', 'Tidak', 'PT. Smart THR Sriwedari Surakarta', 'Jl. Slamet Riyadi Surakarta', ''),
(66, '2014', 'IKA YUNITA PUTRI', 'Pramuniaga', '', 'Tidak', 'PT. BATIK SEMAR Surakarta', 'Jl. Adi Sucipto Surakarta', ''),
(67, '2014', 'IDA IRAWATI', 'Pramuniaga', '', 'Tidak', 'PT. BATIK SEMAR Surakarta', 'Jl. RM Said Surakarta', ''),
(68, '2014', 'M. ANDI AMRULLAH', 'Pramuniaga', '', 'Tidak', 'PT. Smart THR Sriwedari Surakarta', 'Jl. Slamet Riyadi Surakarta', ''),
(69, '2014', 'NUR HAYATI', 'Pramuniaga', '', 'Tidak', 'PT. Smart THR Sriwedari Surakarta', 'Jl. Slamet Riyadi Surakarta', ''),
(70, '2014', 'PUTRI LISTYANTI', 'Pramuniaga', '', 'Tidak', 'PT. BATIK SEMAR Surakarta', 'Jl. Adi Sucipto Surakarta', ''),
(71, '2014', 'PUTRI ASTRID GUNAWAN', 'Pramuniaga', '', 'Tidak', 'Boutiq Zieta', 'Ds Jetis Pegotan Madiun', ''),
(72, '2014', 'RIKA YULIANA', 'Pramuniaga', '', 'Tidak', 'PT. Smart THR Sriwedari Surakarta', 'Jl. Slamet Riyadi Surakarta', ''),
(73, '2014', 'RINA FARDINA RATRI', 'Pramuniaga', '', 'Tidak', 'PT. Smart THR Sriwedari Surakarta', 'Jl. Slamet Riyadi Surakarta', ''),
(74, '2014', 'RATIH APRILIANA', 'Pramuniaga', '', 'Tidak', 'PT. Smart THR Sriwedari Surakarta', 'Jl. Slamet Riyadi Surakarta', ''),
(75, '2014', 'SLAMET SANTOSO', 'Pramuniaga', '-', 'Tidak', 'PT. Smart THR Sriwedari Surakarta', 'Jl. Slamet Riyadi Surakarta', ''),
(76, '2014', 'SYLFA ANGGRITA IGNATIA', 'Pramuniaga', '-', 'Tidak', 'PT. SMART THR SRIWEDARI', 'Jl. Slamet Riyadi Surakarta', ''),
(77, '2014', 'SELI NURVITA', 'Pramuniaga', '-', 'Tidak', 'Rumah Batik Magenta', '', ''),
(78, '2014', 'SRI WURYANTI', 'Pramuniaga', '-', 'Tidak', 'Melanjutkan Sekolah/Kuliah', '', ''),
(79, '2014', 'SITI AISYAH', 'Pramuniaga', '-', 'Tidak', 'PT. Smart THR Sriwedari Surakarta', 'Jl. Slamet Riyadi Surakarta', ''),
(80, '2014', 'VERNANDA REFTIYANA RAMADH', 'Pramuniaga', '-', 'Tidak', 'Boutiq Zieta', 'Ds Jetis Pagotan Madiun', ''),
(81, '2014', 'PANTISA FAJAR WAHYUDI', 'Terapi Refleksologi', 'Nakamura', 'Tidak', 'Klinik Nakamura Balikpapan', 'Jl. Kom Ruko Sentra Eropa 2 Blok AB3 No. 28 Balikp', ''),
(82, '2014', 'RUDI SAPUTRO', 'Terapi Refleksologi', '-', 'Tidak', 'Klinik Nakamura Samarinda', 'Jl. Dermaga No. 34 Samarinda', ''),
(83, '2014', 'ARUM LISTYOWATI', 'Terapi Refleksologi', '-', 'Tidak', 'Klinik Nakamura Kediri', 'Jl. Kom Ruko Hayam Wuruk Blog G 4 Kediri', ''),
(84, '2014', 'ROSIT HERI SAPUTRO', 'Terapi Refleksologi', '-', 'Tidak', 'Klinik Nakamura Samarinda', 'Jl. Dermaga No. 34 Samarinda', ''),
(85, '2014', 'ANGGI SANTRIA', 'Terapi Refleksologi', '-', 'Tidak', 'Klinik Nakamura Makasar', 'Jl. Sungai Saddang Baru No 9D Makasar', ''),
(86, '2014', 'DESI RATNASARI', 'Terapi Refleksologi', '-', 'Tidak', 'Klinik Nakamura Kediri', 'Jl. Kom Ruko Hayam Wuruk Blog G 4 Kediri', ''),
(87, '2014', 'FIKA KARINA DEWI', 'Terapi Refleksologi', '-', 'Tidak', 'Klinik Nakamura Jogja', 'Ruko Pandage Permai No. 12A Sleman', ''),
(88, '2014', 'LORENTIUS DIMAS A.T', 'Terapi Refleksologi', '-', 'Tidak', 'Meninggal Dunia', '', ''),
(89, '2014', 'MOH MUKROMAN', 'Terapi Refleksologi', '-', 'Tidak', 'Klinik Nakamura Jogja', 'Ruko Pandage Permai No. 12A Sleman', ''),
(90, '2014', 'RAHMAD SANTOSO', 'Terapi Refleksologi', '-', 'Tidak', 'Klinik Nakamura Jogja', 'Ruko Pandage Permai No. 12A Sleman', ''),
(91, '2014', 'ERIA ZUSVIRA RAHMA', 'Terapi Refleksologi', '-', 'Tidak', 'Klinik Nakamura Kediri', 'Jl. Kom Ruko Hayam Wuruk Blog G 4 Kediri', ''),
(92, '2014', 'MAHARANI NIRMALA SARI', 'Terapi Refleksologi', '-', 'Tidak', 'Klinik Nakamura Pontianak', 'Jl. Sultan Abdurrahman Pontianak', ''),
(93, '2014', 'ALVIANA BUDIARTI', 'Terapi Refleksologi', '-', 'Tidak', 'Klinik Nakamura Makasar', 'Jl. Sungai Saddang Baru No 9D Makasar', ''),
(94, '2014', 'OKI DWI SAPUTRO', 'Terapi Refleksologi', '-', 'Tidak', 'Klinik Nakamura Makasar', 'Jl. Sungai Saddang Baru No 9D Makasar', ''),
(95, '2014', 'CITRA KUSUMANINGTYAS', 'Terapi Refleksologi', '-', 'Tidak', 'Klinik Nakamura Makasar', 'Jl. Kom Ruko Sentra Eropa 2 Blok AB3 No. 28 Balikp', ''),
(96, '2014', 'TRI OKTAVIANTI N', 'Terapi Refleksologi', '-', 'Tidak', 'Klinik Nakamura Balikpapan', 'Jl. Kom Ruko Sentra Eropa 2 Blok AB3 No. 28 Balikp', ''),
(97, '2014', 'PARWANTI', 'Terapi Refleksologi', '-', 'Tidak', 'Klinik Nakamura Balikpapan', 'Jl. Kom Ruko Sentra Eropa 2 Blok AB3 No. 28 Balikp', ''),
(98, '2014', 'DEVIANA NUR FAHMAWATI', 'Terapi Refleksologi', '-', 'Tidak', 'Klinik Nakamura Balikpapan', 'Jl. Kom Ruko Sentra Eropa 2 Blok AB3 No. 28 Balikp', ''),
(99, '2014', 'YANI SEKARSARI', 'Terapi Refleksologi', '-', 'Tidak', 'Klinik Nakamura Pontianak', 'Jl. Sultan Abdurrahman Pontianak', ''),
(100, '2014', 'ZAKIYYA TURROHMAH', 'Terapi Refleksologi', '-', 'Tidak', 'Klinik Nakamura Samarinda', 'Jl. Dermaga No. 34 Samarinda', ''),
(101, '2014', 'ANIK PRAPTI MULYANI', 'Menjahit', '-', 'Tidak', 'Wirausaha', '', ''),
(102, '2014', 'AISYAH NUR ROHMAH', 'Menjahit', '-', 'Tidak', 'Konveksi Christianto', 'Jl. Pleret Raya No 45 Sumber Surakarta', ''),
(103, '2014', 'CHRISTINA SRI HARTINI', 'Menjahit', '-', 'Tidak', 'Konveksi Christianto', 'Jl. Pleret Raya No 45 Sumber Surakarta', ''),
(104, '2014', 'EUNIKE LUKITASARI', 'Menjahit', '-', 'Tidak', 'Konveksi Christianto', 'Jl. Pleret Raya No 45 Sumber Surakarta', ''),
(105, '2014', 'ENI SUTARTI', 'Menjahit', '-', 'Tidak', 'Konveksi Christianto', 'Jl. Pleret Raya No 45 Sumber Surakarta', ''),
(106, '2014', 'KRISTANA PURWANINGSIH', 'Menjahit', '-', 'Tidak', 'Konveksi Christianto', 'Jl. Pleret Raya No 45 Sumber Surakarta', ''),
(107, '2014', 'KUSNUL KHOTIMAH', 'Menjahit', '-', 'Tidak', 'Konveksi Qodri', 'Perum Tiara Ardi GG Melati No. H 25 Purbayan', ''),
(108, '2014', 'LATIFAH SRI MAHARSI', 'Menjahit', '-', 'Tidak', 'Konveksi Christianto', 'Jl. Pleret Raya No 45 Sumber Surakarta', ''),
(109, '2014', 'MARYAM EKO NUR R', 'Menjahit', '-', 'Tidak', 'Konveksi Mudatun', 'Jl. Markisah 2 Karangasem Surakarta', ''),
(110, '2014', 'MARYANTI', 'Menjahit', '-', 'Tidak', 'Konveksi Christianto', 'Jl. Pleret Raya No 45 Sumber Surakarta', ''),
(111, '2014', 'MARYANI', 'Menjahit', '-', 'Tidak', 'Konveksi Christianto', 'Jl. Pleret Raya No 45 Sumber Surakarta', ''),
(112, '2014', 'YUNIN PRAMESTI', 'Menjahit', '-', 'Tidak', 'Konveksi Christianto', 'Jl. Pleret Raya No 45 Sumber Surakarta', ''),
(113, '2014', 'WIJI LESTARI', 'Menjahit', '-', 'Tidak', 'Konveksi Christianto', 'Jl. Pleret Raya No 45 Sumber Surakarta', ''),
(114, '2014', 'SUNARNI', 'Menjahit', '-', 'Tidak', 'Konveksi Christianto', 'Jl. Pleret Raya No 45 Sumber Surakarta', ''),
(115, '2014', 'WISUDASTUTI WIDI W', 'Menjahit', '-', 'Tidak', 'Konveksi Christianto', 'Jl. Pleret Raya No 45 Sumber Surakarta', ''),
(116, '2014', 'SUPRIASIH', 'Menjahit', '-', 'Tidak', 'Konveksi Christianto', 'Jl. Pleret Raya No 45 Sumber Surakarta', ''),
(117, '2014', 'NURUL KHOMARIAH', 'Menjahit', '-', 'Tidak', 'Konveksi Christianto', 'Jl. Pleret Raya No 45 Sumber Surakarta', ''),
(118, '2014', 'NUR AZALIYAH', 'Menjahit', '-', 'Tidak', 'Penjahit Galuh', 'Jl. Gatot Kaca Cemani Grogol Sukoharjo', ''),
(119, '2014', 'NUR EKOWATI', 'Menjahit', '-', 'Tidak', 'Konveksi Christianto', 'Jl. Pleret Raya No 45 Sumber Surakarta', ''),
(120, '2014', 'NURISMA KUSUMA SARI', 'Menjahit', '-', 'Tidak', 'Konveksi Christianto', 'Jl. Pleret Raya No 45 Sumber Surakarta', '');

-- --------------------------------------------------------

--
-- Table structure for table `peserta`
--

CREATE TABLE IF NOT EXISTS `peserta` (
`id` int(3) NOT NULL,
  `ta` int(4) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `tempatlahir` varchar(20) DEFAULT NULL,
  `tgllahir` date DEFAULT NULL,
  `pendidikan` varchar(20) DEFAULT NULL,
  `alamat` varchar(70) DEFAULT NULL,
  `nohp` varchar(12) DEFAULT NULL,
  `kejuruan` varchar(20) DEFAULT NULL,
  `photo` blob
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `peserta`
--

INSERT INTO `peserta` (`id`, `ta`, `nama`, `tempatlahir`, `tgllahir`, `pendidikan`, `alamat`, `nohp`, `kejuruan`, `photo`) VALUES
(1, 2014, 'AANG KHUNAIFI ULINUHA', 'Surakarta', '1974-11-01', 'SMA', 'Randusari RT 2/30, Mojosongo Jebres Surakarta', '', 'Pramuniaga', ''),
(2, 2014, 'ANGGARA RETNA PALUPI', 'Surakarta', '1994-07-28', 'SMK', 'Pucangsawit RT 3/4 Jebres Surakarta', '', 'Pramuniaga', ''),
(3, 2014, 'DEVINTA LUSI LUFIKASARI', 'Surakarta', '1994-05-11', 'SMA', 'Kusumodilagan RT 4/12 Joyosuran Pasar Kliwon, SKA', '', 'Pramuniaga', ''),
(4, 2014, 'HAFIDHZYAN MALIK', 'Surakarta', '1995-03-04', 'SMA', 'Turisari RT 1/11 Mangkubumen Banjarsari SKA', '', 'Pramuniaga', ''),
(5, 2014, 'HERI KURNIYAWAN', 'Surakarta', '1994-01-30', 'SMK', 'Bibis Kulon RT 4/16 Gilingan Banjarsari Surakarta', '', 'Pramuniaga', ''),
(6, 2014, 'IKA YUNITA PUTRI', 'Surakarta', '1993-06-27', 'SMK', 'Jetis RT 2/3 Kadipiro Banjarsari Surakarta', NULL, 'Pramuniaga', NULL),
(7, 2014, 'IDA IRAWATI', 'Surakarta', '1994-08-12', 'SMK', 'Kandangsapi RT 5/1 Tegalharjo Jebres Surakarta', '', 'Pramuniaga', ''),
(8, 2014, 'M. ANDI AMRULLAH', 'Pasuruan', '1992-10-06', 'SMK', 'Mertodranan RT 3/3 Pasar Kliwon Surakarta', '', 'Pramuniaga', ''),
(9, 2014, 'NUR HAYATI', 'Surakarta', '1991-03-02', 'SMK', 'Semanggi RT 2/19 Pasar Kliwon Surakarta', '', 'Pramuniaga', ''),
(10, 2014, 'PUTRI LISTYANTI', 'Surakarta', '1994-10-17', '', 'Kandangsapi RT 1/35 Jebres Surakarta', '', 'Pramuniaga', ''),
(11, 2014, 'PUTRI ASTRID GUNAWAN', 'Surakarta', '1995-05-02', 'SMK', 'Butuh RT 4/3 Gandekan Jebres Surakarta', '', 'Pramuniaga', ''),
(12, 2014, 'RIKA YULIANA', 'Nganjuk', '1995-07-10', 'SMK', 'Jogobayan RT 1/6 Setabelan Banjarsari Surakarta', '', 'Pramuniaga', ''),
(13, 2014, 'RINA FARDINA RATRI', 'Surakarta', '1995-10-17', 'SMA', 'Sriwedari RT 1/3 Laweyan Surakarta', '', 'Pramuniaga', ''),
(14, 2014, 'RATIH APRILIANA', 'Surakarta', '1992-04-24', 'SMK', 'Semanggi RT 3/3 Pasar Kliwon Surakarta', '', 'Pramuniaga', ''),
(15, 2014, 'SLAMET SANTOSO', 'Palembang', '1992-03-12', 'SMK', 'Purwonegaran RT 3/5 Sriwedari Laweyan Surakarta', '', 'Pramuniaga', ''),
(16, 2014, 'SYLFA ANGGRITA IGNATIA', 'Surakarta', '1992-01-04', 'SMK', 'Jl. Pakel No. 22 RT 1/8 Kerten Laweyan Surakarta', '', 'Pramuniaga', ''),
(17, 2014, 'SELI NURVITA', 'Surakarta', '1994-02-15', 'SMK', 'Purbowardayan RT 1/2 Tegalharjo Jebres Surakarta', '', 'Pramuniaga', ''),
(18, 2014, 'SRI WURYANTI', 'Surakarta', '1993-12-05', 'SMK', 'Banyuanyar RT 1/8 Banjarsari Surakarta', '', 'Pramuniaga', ''),
(19, 2014, 'SITI AISYAH', 'Surakarta', '1993-01-24', 'SMA', 'Jl. Kepodang no.12 RT 2/1 Kerten Laweyan Surakarta', '', 'Pramuniaga', ''),
(20, 2014, 'VERNANDA REFTIYANA RAMADH', 'Surakarta', '1987-01-24', 'SMA', 'Jajar RT 3/4 Laweyan Surakarta', '', 'Pramuniaga', ''),
(21, 2014, 'PANTISA FAJAR WAHYUDI', 'Surakarta', '1986-12-11', 'SMK', 'Plelen RT 3/33 Kadipiro Surakarta', '', 'Terapi Refleksologi', ''),
(22, 2014, 'RUDI SAPUTRO', 'Surakarta', '1994-11-24', 'SMP', 'Purwosari RT 3/13 Laweyan Surakarta', '', 'Terapi Refleksologi', ''),
(23, 2014, 'ARUM LISTYOWATI', 'Wonogiri', '1997-07-20', 'SMP', 'Jl. Kahuripan Barat 3 No.2 RT 3/6 Sumber Surakarta', '', 'Terapi Refleksologi', ''),
(24, 2014, 'ROSIT HERI SAPUTRO', 'Sragen', '1992-11-03', 'SMP', 'Bibis Kulon RT 5/17 Gilingan Surakarta', '', 'Terapi Refleksologi', ''),
(25, 2014, 'ANGGI SANTRIA', 'Surakarta', '1995-01-30', 'SMA', 'Debegan RT 4/5 Mojosongo Surakarta', '', 'Terapi Refleksologi', ''),
(26, 2014, 'DESI RATNASAR', 'Surakarta', '1994-12-15', 'SMP', 'Dawung Tengah RT 2/XIV Serengan Surakarta', '', 'Terapi Refleksologi', ''),
(27, 2014, 'FIKA KARINA DEWI', 'Surakarta', '1990-07-28', 'SMP', 'Bibis Baru RT 7/23 Nusukan Surakarta', '', 'Terapi Refleksologi', ''),
(28, 2014, 'LORENTIUS DIMAS A.T', 'Surakarta', '1989-02-11', 'SMA', 'Pucangsawit RT 2/13 Jebres Surakarta', '', 'Terapi Refleksologi', ''),
(29, 2014, 'MOH MUKROMAN', 'Pekalongan', '1996-05-23', 'SMK', 'Jl. Surya 2 RT 6/25 Jebres Surakarta', '', 'Terapi Refleksologi', ''),
(30, 2014, 'RAHMAD SANTOSO', 'Surakarta', '1994-08-22', 'SMK', 'Makam Bergolo RT 4/8 Serengan Surakarta', '', 'Terapi Refleksologi', ''),
(31, 2014, 'OKI DWI SAPUTRO', 'Surakarta', '1992-10-08', 'SD', 'Bibis kulon 1/17 Gilingan Surakarta', '', 'Terapi Refleksologi', ''),
(32, 2014, 'ALVIANA BUDIARTI', 'Pekalongan', '1991-07-30', 'SMK', 'Jl. Tambak Segaran No. 31 F RT 2/7 Banjarsari Surakarta', '', 'Terapi Refleksologi', ''),
(33, 2014, 'MAHARANI NIRMALA SARI', 'Surakarta', '1996-01-07', 'SMK', 'Jagalan RT 3/14 Jebres Surakarta', '', 'Terapi Refleksologi', ''),
(34, 2014, 'PARWANTI', 'Surakarta', '1983-06-21', 'SMK', 'Sumber tapen RT 2/3 Banjarsari Surakarta', '', 'Terapi Refleksologi', ''),
(35, 2014, 'TRI OKTAVIANTI N', 'Surakarta', '1992-10-23', 'SMK', 'Tegalrejo RT 3/4 Jebres Surakarta', '', 'Terapi Refleksologi', ''),
(36, 2014, 'CITRA KUSUMANINGTYAS', 'Surakarta', '1995-03-05', 'SMP', 'Bororejo RT 2/V Jagalan Surakarta', '', 'Terapi Refleksologi', ''),
(37, 2014, 'ERIA ZUSVIRA RAHMA', 'Surakarta', '1995-06-23', 'SMP', 'Bayan RT 02/27 Kadipiro Surakarta', '', 'Terapi Refleksologi', ''),
(38, 2014, 'YANI SEKARSARI', 'Surakarta', '1995-01-10', 'SMP', 'Pucangsawit RT 2/13 Jebres Surakarta', '', 'Terapi Refleksologi', ''),
(39, 2014, 'ZAKIYYA TURROHMAH', 'Surakarta', '1993-12-23', 'SMK', 'Semanggi RT 8/4 Pasar Kliwon Surakarta', '', 'Terapi Refleksologi', ''),
(40, 2014, 'DEVIANA NUR FAHMAWATI', 'Surakarta', '1992-12-23', 'SMK', 'Notosuman RT 6/2 Jayengan Serengan Surakarta', '', 'Terapi Refleksologi', ''),
(41, 2014, 'ANIK PRAPTI MULYANI', 'Surakarta', '1974-11-01', 'SMA', 'Sangkrah RT 04/01 Pasar Kliwon Surakarta', '', 'Menjahit', ''),
(42, 2014, 'AISYAH NUR ROHMAH', 'Surakarta', '1996-01-10', 'SMP', 'Jetis RT 05/03 Kadipiro Banjarsari Surakarta', '', 'Menjahit', ''),
(43, 2014, 'CHRISTINA SRI HARTINI', 'Surakarta', '1974-02-14', 'SMP', 'Cengklik RT 03/20 Nusukan Surakarta', '', 'Menjahit', ''),
(44, 2014, 'EUNIKE LUKITASARI', 'Surakarta', '1992-03-18', 'SMP', 'Sendang Mulyo RT 5/18 Kadipiro Surakarta', '', 'Menjahit', ''),
(45, 2014, 'ENI SUTARTI', 'Surakarta', '1975-07-07', 'SMA', 'Sumber Nayu RT 2/12 Kadipiro Surakarta', '', 'Menjahit', ''),
(46, 2014, 'KRISTANA PURWANINGSIH', 'Surakarta', '1976-10-21', 'SMP', 'Ngemplak Rejosari RT 06/15 Banjarsari Surakarta', '', 'Menjahit', ''),
(47, 2014, 'KUSNUL KHOTIMAH', 'Surakarta', '1991-11-16', 'SMP', 'Jl. Manduro RT 03/03 Kratonan Serengan Surakarta', '', 'Menjahit', ''),
(48, 2014, 'LATIFAH SRI MAHARSI', 'Surakarta', '1982-11-10', 'SMA', 'Sambirejo RT 2/9 Kadipiro Banjarsari Surakarta', '', 'Menjahit', ''),
(49, 2014, 'MARYAM EKO NUR R', 'Surakarta', '1990-08-25', 'SMP', 'Jl. Lampo Batang Tengah 1/6 Mojosongo Surakarta', '', 'Menjahit', ''),
(50, 2014, 'MARYANTI', 'Surakarta', '1985-02-18', 'SMP', 'Ngadisono RT 05/14 Kadipiro Banjarsari Surakarta', '', 'Menjahit', ''),
(51, 2014, 'MARYANI', 'Surakarta', '1985-02-18', 'SMA', 'Prawit RT 4/3 Nusukan Banjarsari Surakarta', '', 'Menjahit', ''),
(52, 2014, 'NURUL KHOMARIAH', 'Surakarta', '1987-07-02', 'SMA', 'Jl. Manduro RT 03/03 Kratonan Serengan Surakarta', '', 'Menjahit', ''),
(53, 2014, 'NURISMA KUSUMA SARI', 'Surakarta', '1994-03-03', 'SMP', 'Jagalan RT 03/10 Jebres Surakarta', '', 'Menjahit', ''),
(54, 2014, 'NUR EKOWATI', 'Surakarta', '1978-02-23', 'SMP', 'Gedong Serut RT 05/10 Kadipiro Banjarsari Surakarta', '', 'Menjahit', ''),
(55, 2014, 'NUR AZALIYAH', 'Surakarta', '1981-04-25', 'SMP', 'Jl. Poconoko IV RT 3/3 Tipes Serengan Surakarta', '', 'Menjahit', ''),
(56, 2014, 'SUPRIASIH', 'Surakarta', '1980-02-13', 'SMP', 'Ngadisono RT 01/14 Kadipiro Banjarsari Surakarta', '', 'Menjahit', ''),
(57, 2014, 'SUNARNI', 'Surakarta', '1980-02-13', 'SMP', 'Jl. Dempo Dalam II RT 1/3 Mojosongo Jebress Surakarta', '', 'Menjahit', ''),
(58, 2014, 'WISUDASTUTI WIDI W', 'Surakarta', '1990-05-17', 'SMP', 'Jl. S.Sambas 81 Sangkrah RT 4/1 Surakarta', '', 'Menjahit', ''),
(59, 2014, 'WIJI LESTARI', 'Surakarta', '1976-11-11', 'SMA', 'Ngampon RT 4/4 Mojosongo Jebres Surakarta', '', 'Menjahit', ''),
(60, 2014, 'YUNIN PRAMESTI', 'Surakarta', '1982-06-19', 'SMA', 'Jl. Merapi Dalam II No.3 RT 1/19 Cengklik Nusukan Surakarta', '', 'Menjahit', ''),
(61, 2015, 'ANDRIAN KRISNAMURTI D', 'Surakarta', '1995-09-22', 'SMK', 'Jl. Mliwis VI No.6 RT. 08/07, Manahan, Banjarsari Surakarta', '', 'Desain Grafis', ''),
(62, 2015, 'ANDIKA RIZAL H', 'Surakarta', '1990-09-22', 'D3', 'Purwosari RT.5/8 Purwosari Laweyan Surakarta', '', 'Desain Grafis', ''),
(63, 2015, 'APRILIA HANA CHRISTIANA', 'Surakarta', '1996-04-23', 'SMK', 'Dukuhan Nayu RT07/15 Kadipiro Banjarsari Surakarta', '', 'Desain Grafis', ''),
(64, 2015, 'CHRISTIANTO WIBOWO', 'Surakarta', '1990-08-24', 'SMK', 'Wonorejo RT.01/02 Pajang Laweyan Surakarta', '', 'Desain Grafis', ''),
(65, 2015, 'DWI KUNCORO HADI', 'Wonogiri', '1992-07-08', 'D3', 'Kusumodilagan RT. 02/10 Joyosuran Pasar Kliwon Surakarta', '', 'Desain Grafis', ''),
(66, 2015, 'DEWI PRASETYOWATI', 'Magelang', '1982-07-05', 'D3', 'Jl. Seruni 2 No. 19 Mangkubumen Banjarsari Surakarta', '', 'Desain Grafis', ''),
(67, 2015, 'DIAH PERMATA DEWI Y', 'Surakarta', '1990-07-28', 'SMK', 'Dawung Kulon RT.01/X Serengan Surakarta', '', 'Desain Grafis', ''),
(68, 2015, 'DIAN CANDRA S', 'Surakarta', '1995-03-23', 'SMA', 'Semanggi RT.01/16 Semanggi Pasar Kliwon, Surakarta', '', 'Desain Grafis', ''),
(69, 2015, 'DWI RIZKY FAUZIAH', 'Surakarta', '1992-06-24', 'smk', 'Jl. Rinjani Timur II/13 RT.03/19 Mojosongo Jebres Surakarta', '', 'Desain Grafis', ''),
(70, 2015, 'DIAN CAHYA CINTAMI', 'Surakarta', '1993-09-15', 'SMA', 'Bratan Pajang RT.01/06 Pajang Laweyan Surakarta', '', 'Desain Grafis', ''),
(71, 2015, 'DIMAS SAPUTRO', 'Surakarta', '1994-03-22', 'SMK', 'Tegalmulyo RT.03/07 Purwosari Laweyan Surakarta', '', 'Desain Grafis', ''),
(72, 2015, 'FARIZ I BAHTIAR', 'Pekalongan', '1991-07-30', 'SMK', 'Tempen Baturono RT 01/03 Pasar Kliwon Surakarta', '', 'Desain Grafis', ''),
(73, 2015, 'GARENDHI KUKUH', 'Blora', '1992-03-16', 'D3', 'Busukan RT.02/27 Mojosongo Jebres Surakarta', '', 'Desain Grafis', ''),
(74, 2015, 'HARI RHOMADHONY AWAN', 'Surakarta', '1983-06-21', 'SMK', 'DIpotrunan RT.01/12 Tipes Serengan Surakarta', '', 'Desain Grafis', ''),
(75, 2015, 'KADARSIH ESTI', 'Surakarta', '1994-01-03', 'SMK', 'Karang Asem RT.02/16 Kadipiro Banjarsari Surakarta', '', 'Desain Grafis', ''),
(76, 2015, 'NURAENI TRISNAWATI', 'Surakarta', '1995-12-10', 'SMK', 'Banyuanyar RT.02/XI, Banjarsari Surakarta', '', 'Desain Grafis', ''),
(77, 2015, 'RONI MUSTOFA', 'Surakarta', '1992-01-19', 'SMA', 'Losari RT.02/03 Semanggi Pasar Kliwon Surakarta', '', 'Desain Grafis', ''),
(78, 2015, 'TETUKO BAYU AJI', 'Surakarta', '1996-06-09', 'SMA', 'Sumber RT. 04/06 Banjarsari Surakarta', '', 'Desain Grafis', ''),
(79, 2015, 'WINDITYAS F N', 'Surakarta', '1985-02-05', 'D3', 'Bayan Krajan RT.08/20 Kadipiro Banjarsari Surakarta', '', 'Desain Grafis', ''),
(80, 2015, 'ZIANA YULIANTI', 'Batang', '1996-07-02', 'SMA', 'Semanggi RT 05/03 Semanggi Pasar Kliwon Surakarta', '', 'Desain Grafis', ''),
(81, 2015, 'ANIK SUSILOWATI', 'Surakarta', '1986-05-14', 'SMK', 'Sumber RT 4/4 Banjarsari Surakarta', '', 'Menjahit', ''),
(82, 2015, 'AMINUDIN', 'Surakarta', '1998-04-02', 'SMP', 'Songgalan RT 3/4 Pajang Laweyan Surakarta', '', 'Menjahit', ''),
(83, 2015, 'CAHYANI ENDRI S', 'Surakarta', '1989-02-08', 'SMP', 'Belukan RT 4/4 Pajang Laweyan Surakarta', '', 'Menjahit', ''),
(84, 2015, 'CAHYANI PURNAMASARI', 'Surakarta', '1996-05-29', 'SMA', 'Kagokan RT 3/11 Pajang Laweyan Surakarta', '', 'Menjahit', ''),
(85, 2015, 'CUT HANY SORAYA', 'Surakarta', '1985-10-14', 'SMA', 'Karangasem RT 4/8 Karangasem Laweyan Surakarta', '', 'Menjahit', ''),
(86, 2015, 'ERNI SISI LASMANY', 'Surakarta', '1976-09-02', 'SMK', 'Jl. Tarumanegara III No.4 RT 2/6 Banyuanyar Surakarta', '', 'Menjahit', ''),
(87, 2015, 'EFNI RATNAWATI A', 'Surakarta', '1979-11-06', 'SMA', 'Jantirejo RT 3/13 Sondakan Laweyan Surakarta', '', 'Menjahit', ''),
(88, 2015, 'ENDANG MULYANI, SE', 'Surakarta', '1979-09-28', 'S1', 'Jl. Parang Klitik No.9 RT 1/5 Sondakan Laweyan Surakarta', '', 'Menjahit', ''),
(89, 2015, 'FATIMAH DWI FAUZIAH', 'Surakarta', '1994-02-24', 'SMA', 'Jajar RT 7/III GG Delima VIII Laweyan Surakarta', '', 'Menjahit', ''),
(90, 2015, 'KUMPUL BARWANTO', 'Kebumen', '1978-06-05', 'D3', 'Villa Palem Mas B-3 RT 6/32 Mojosongo Jebres Surakarta', '', 'Menjahit', ''),
(91, 2015, 'KRISTANTI', 'Surakarta', '1997-04-03', 'SMK', 'Sonatan RT 1/2 Banyuanyar Banjarsari Surakarta', '', 'Menjahit', ''),
(92, 2015, 'NIKEN LARAS ASRI', 'Surakarta', '1967-05-21', 'SMA', 'Jl. Kahuripan No.73 RT1/10 Sumber Banjarsari Surakarta', '', 'Menjahit', ''),
(93, 2015, 'RIRIN LISTYANINGRUM', 'Surakarta', '1980-12-13', 'SMA', 'Banyuanyar RT 2/6 Banjarsari Surakarta', '', 'Menjahit', ''),
(94, 2015, 'SITI ANIK NURUL CHASANAH', 'Surakarta', '1990-10-26', 'SMA', 'Banyuanyar Banjarsari Surakarta', '', 'Menjahit', ''),
(95, 2015, 'SRIWIJAYA PURBA H', 'Surakarta', '1988-12-23', 'SMP', 'Sidodadi RT 5/1 Pajang Laweyan Surakarta', '', 'Menjahit', ''),
(96, 2015, 'SRI LESTARI', 'Sukoharjo', '1987-03-27', 'SMP', '', '', 'Menjahit', ''),
(97, 2015, 'TIN BINTARI', 'Surakarta', '1996-05-01', 'SMK', 'Sumber RT 2/16 Banjarsari Surakarta', '', 'Menjahit', ''),
(98, 2015, 'WENY PUJIASTUTI', 'Surakarta', '1975-10-30', 'SMA', 'Bayan RT 1/7 Kadipiro Banjarsari Surakarta', '', 'Menjahit', ''),
(99, 2015, 'YOHANA FRANCISKA DIAN R', 'Purwokerto', '1987-12-18', 'SMA', 'Semanggi RT 3/13 Semanggi Surakarta', '', 'Menjahit', ''),
(100, 2015, 'ZULFA NURHAYATI', 'Surakarta', '1996-10-25', 'SMK', 'Songgalan RT 3/4 Pajang Laweyan Surakarta', '', 'Menjahit', ''),
(101, 2015, 'ANDREW WIRASANJAYA P', 'Majalengka', '1997-08-29', 'SMA', 'Jl. Kepel Timur 2 RT 1/1 Karangasem Laweyan Surakarta', '', 'OTOMOTIF', ''),
(102, 2015, 'ARDIANSYAH TEJA MUKTIARA', 'Surakarta', '1996-12-03', 'SMK', 'Majapahit 1 NO. 28 RT 5/14 Nusukkan Surakarta', '', 'OTOMOTIF', ''),
(103, 2015, 'AGUNG PRIYAMBODO', 'Surakarta', '1996-11-05', 'SMK', 'Pucangsawit RT 1/11 Jebres Surakarta', '', 'OTOMOTIF', ''),
(104, 2015, 'ANGGI DAVIYARTO', 'Sukoharjo', '1994-08-21', 'SMA', 'Makam Bergolo RT 3/VII Serengan Surakarta', '', 'OTOMOTIF', ''),
(105, 2015, 'ARRIZAL NOOR HERMANSYAH', 'Surakarta', '1996-01-11', 'SMA', 'Pucangsawit RT 3/3 Jebres Surakarta', '', 'OTOMOTIF', ''),
(106, 2015, 'ADHI PAMUNGKAS', 'Sukoharjo', '1994-12-03', 'SMK', 'Tunggulsari RT 6/16 Pajang Laweyan Surakarta', '', 'OTOMOTIF', ''),
(107, 2015, 'ARROFI YUDHA SAKTI', 'Surakarta', '1996-11-06', 'SMA', 'Pucangsawit RT 3/3 Jebres Surakarta', '', 'OTOMOTIF', ''),
(108, 2015, 'DANI BAGUS RAHMADI', 'Surakarta', '1993-07-14', 'SMK', 'Makam Bergolo RT 2/8 Serengan Surakarta', '', 'OTOMOTIF', ''),
(109, 2015, 'DEDY ISWANTO', 'Surakarta', '1994-06-16', 'SMA', 'Gebang Kadipiro RT 6/17 Banjarsari Surakarta', '', 'OTOMOTIF', ''),
(110, 2015, 'DWI PURWOKO', 'Wonogiri', '1997-03-15', 'SMK', 'Jagobayan RT 5/6 Setabelan Banjarsari Surakarta', '', 'OTOMOTIF', ''),
(111, 2015, 'ESADULLAH AHMAD YENSA', 'Surakarta', '1997-04-12', 'SMK', 'Pucangsawit RT 1/3 Pucangsawit Jebres Surakarta', '', 'OTOMOTIF', ''),
(112, 2015, 'FAJAR ADI JATMIKO', 'Boyolali', '1992-12-29', 'SMA', 'Karangturi RT 2/7 Pajang Laweyan Surakarta', '', 'OTOMOTIF', ''),
(113, 2015, 'NUR UTOMO BAYU AJI', 'Surakarta', '1997-03-25', 'SMK', 'Pucangsawit RT 2/14 Pucangsawit Jebres Surakarta', '', 'OTOMOTIF', ''),
(114, 2015, 'RIZQI TRI ARYADI', 'Surakarta', '1995-03-09', 'SMK', 'Sendang Mulyo RT 5/18 Kadipiro Banjarsari Surakarta', '', 'OTOMOTIF', ''),
(115, 2015, 'RADITYA SETYAWAN', 'Surakarta', '1996-08-09', 'SMK', 'Jogobayan RT 4/5 Setabelan Banjarsari Surakarta', '', 'OTOMOTIF', ''),
(116, 2015, 'ROLEX ROSINDA', 'Surakarta', '1996-04-11', 'SMK', 'Semanggi RT 5/17 Semanggi pasar Kliwon Surakarta', '', 'OTOMOTIF', ''),
(117, 2015, 'RIDHO MARHENDRA', 'Surakarta', '1997-03-23', 'SMK', 'Johobayan RT 2/6 Setabelan Banjarsari Surakarta', '', 'OTOMOTIF', ''),
(118, 2015, 'VINCENT ADITYA PRASETYA', 'Surakarta', '1997-03-18', 'SMA', 'Sidodadi RT 6/6 Pajang Laweyan Surakarta', '', 'OTOMOTIF', ''),
(119, 2015, 'WITANTO', 'Karanganyar', '1979-09-29', 'SMK', 'Nusukan RT 3/24 Banjarsari Surakarta', '', 'OTOMOTIF', ''),
(120, 2015, 'FEBRI PURWANTO', 'Surakarta', '1996-04-20', 'SMK', 'Pucangsawit RT 1/4 Pucangsawit Jebres Surakarta', '', 'OTOMOTIF', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kejuruan`
--
ALTER TABLE `kejuruan`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lembaga`
--
ALTER TABLE `lembaga`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `penempatan`
--
ALTER TABLE `penempatan`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `peserta`
--
ALTER TABLE `peserta`
 ADD PRIMARY KEY (`id`), ADD KEY `id` (`id`), ADD KEY `id_2` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
MODIFY `id` int(2) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `lembaga`
--
ALTER TABLE `lembaga`
MODIFY `id` int(2) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT for table `penempatan`
--
ALTER TABLE `penempatan`
MODIFY `id` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=121;
--
-- AUTO_INCREMENT for table `peserta`
--
ALTER TABLE `peserta`
MODIFY `id` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=121;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

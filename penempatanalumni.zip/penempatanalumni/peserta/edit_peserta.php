<?php
include "../include/koneksi_db.php";
include "../peserta/link.php";

$id		= isset($_GET['id']) ? $_GET['id'] : "";

if ($id == "") {
	echo "<script>alert('Pilih dulu data yang akan di-update');</script>";
	echo "<meta http-equiv='refresh' content='0; url=lihat_peserta.php'>";
} else {
	$query		= mysql_query("SELECT * FROM peserta WHERE id=$id", $konek);
	$hasil		= mysql_fetch_array($query);
	$id  		= $hasil['id'];
	$ta 		= $hasil['ta'];
	$nama 		= $hasil['nama'];
	$tempatlahir= $hasil['tempatlahir'];
	$tgllahir	= $hasil['tgllahir'];
	$pendidikan	= $hasil['pendidikan'];
	$alamat		= $hasil['alamat'];
	$nohp		= $hasil['nohp'];
	$kejuruan	= $hasil['kejuruan'];

}
?>

<form method="post" action="?page=act_edit_peserta">
<table width=100% border=1 class="table-data">
<input type="hidden" name="id" value="<?php echo $id; ?>">
<tr><td class="head-data" colspan="2">Edit Data Peserta : <?php echo $nama; ?></td></tr>
<tr><td class="pinggir-data">Tahun Anggaran</td>
<td class="pinggir-data"><input type="text" size="65" name="ta" value="<?php echo $ta; ?>"></td></tr>
<tr><td class="pinggir-data">Peserta</td>
<td class="pinggir-data"><input type="text" size="65" name="nama" value="<?php echo $nama; ?>"></td></tr>
<tr><td class="pinggir-data">Tempat Lahir</td>
<td class="pinggir-data"><input type="text"  size="65" name="tempatlahir" value="<?php echo $tempatlahir; ?>"></td></tr>
<tr><td class="pinggir-data">Tanggal Lahir</td>
<td class="pinggir-data"><input type="text" size="15"name="tgllahir" value="<?php echo $tgllahir; ?>"></td></tr>
<tr><td class="pinggir-data">Pendidikan Terakhir</td>
<td class="pinggir-data"><input type="text" size="65" name="pendidikan" value="<?php echo $pendidikan; ?>"></td></tr>
<tr><td class="pinggir-data">Alamat</td>
<td class="pinggir-data"><input type="text" size="65" name="alamat" value="<?php echo $alamat; ?>"></td></tr>
<tr><td class="pinggir-data">No Telp/HP</td>
<td class="pinggir-data"><input type="text" size="25" name="nohp" value="<?php echo $nohp; ?>"></td></tr>
<tr><td class="pinggir-data">Kejuruan</td>
<td class="pinggir-data"><input type="text" size="25"name="kejuruan" value="<?php echo $kejuruan; ?>"></td></tr>
<tr><td class="head-data" colspan="2" align="center">
<input type="submit" value="Update">
</td></tr>
</table>
</form>
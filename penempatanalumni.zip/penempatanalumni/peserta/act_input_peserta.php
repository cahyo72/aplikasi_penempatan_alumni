<?php
include "../include/koneksi_db.php"; //memanggil file koneksi_db.php
include "../include/fungsi2.php"; //memanggil file fungsi.php

$ta			= isset($_POST['ta']) ? addslashes($_POST['ta']) : "";
$nama		= isset($_POST['nama']) ? addslashes($_POST['nama']) : "";
$tempatlahir= isset($_POST['tempatlahir']) ? addslashes($_POST['tempatlahir']) : "";
$tgllahir	= isset($_POST['tgllahir']) ? addslashes($_POST['tgllahir']) : "";
$pendidikan	= isset($_POST['pendidikan']) ? addslashes($_POST['pendidikan']) : "";
$alamat		= isset($_POST['alamat']) ? addslashes($_POST['alamat']) : "";
$nohp		= isset($_POST['nohp']) ? addslashes($_POST['nohp']) : "";
$kejuruan	= isset($_POST['kejuruan']) ? addslashes($_POST['kejuruan']) : "";
$photo		= isset($_POST['photo']) ? addslashes($_POST['photo']) : "";





	$cek=mysql_query("SELECT * FROM peserta WHERE nama='$nama'", $konek);
	$hasil_cek=mysql_num_rows($cek);

	$query = mysql_query("INSERT INTO peserta VALUES (NULL,'$ta', '$nama', '$tempatlahir', '$tgllahir', '$pendidikan', '$alamat', '$nohp', '$kejuruan', '$photo')");

		if ($query) {
			echo "<script>alert('Data berhasil ditambahkan @ $hari_ini. Terima Kasih')</script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=input_peserta'>";
		} else {
			echo "<script>alert('Data anda gagal dimasukkan karena. Ulangi sekali lagi')</script>";
			echo mysql_error();
			//echo "<meta http-equiv='refresh' content='0; url=?page=input_peserta'>";
		}
?>
<?php
include "../include/koneksi_db.php";
include "../peserta/link.php";

$nama	= isset($_GET['nama']) ? $_GET['nama'] : "";

$query=mysql_query("SELECT * FROM peserta WHERE nama='$nama'", $konek);
$hasil=mysql_fetch_array($query);
?>
<table class="table-data" width=100% border=1>
	<tr><td colspan="2" class="head-data">Data Detail Alumni : "<?php echo $nama; ?>"</td></tr>
	<tr><td class="pinggir-data">Tahun Anggaran</td><td class="pinggir-data"><?php echo $hasil[1]; ?></td></tr>
	<tr><td class="pinggir-data">Nama</td><td class="pinggir-data"><?php echo $hasil[2]; ?></td></tr>
	<tr><td class="pinggir-data">Tempat Lahir</td><td class="pinggir-data"><?php echo $hasil[3]; ?></td></tr>
	<tr><td class="pinggir-data">Tanggal lahir</td><td class="pinggir-data"><?php echo $hasil[4]; ?></td></tr>
	<tr><td class="pinggir-data">Pendidikan Terakhir</td><td class="pinggir-data"><?php echo $hasil[5]; ?></td></tr>
	<tr><td class="pinggir-data">Alamat</td><td class="pinggir-data"><?php echo $hasil[6]; ?></td></tr>
<tr><td class="pinggir-data">No HP</td><td class="pinggir-data"><?php echo $hasil[7]; ?>></td></tr>
	<tr><td class="pinggir-data">Kejuruan Pelatihan</td><td class="pinggir-data"><?php echo $hasil[8]; ?></td></tr>
	
	
	
</table>
	

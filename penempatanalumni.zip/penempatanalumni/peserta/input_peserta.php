<?php include "../peserta/link.php"; ?>
<form method="post" action="?page=act_input_peserta">
<table width=100% border=1 class="table-data">
<tr><td class="head-data" colspan="2">Tambah Alumni</td></tr>
<tr><td class="pinggir-data">Tahun Anggaran</td>
<td class="pinggir-data"><select name="ta">
							<option value="">..:: Silahkan Pilih Tahun Anggaran ::..</option>
							<option value="2014">2014</option>
							<option value="2015">2015</option>
							<option value="2016">2016</option>
							<option value="2017">2017</option>
							<option value="2018">2018</option>
							<option value="2019">2019</option>
							<option value="2020">2020</option>
</td></tr>
<tr><td class="pinggir-data">Nama</td>
<td class="pinggir-data"><input type="text" name="nama" size="65"></td></tr>
<tr><td class="pinggir-data">Tempat Lahir</td>
<td class="pinggir-data"><input type="text" name="tempatlahir" size="65"></td></tr>
<tr><td class="pinggir-data">Tgl Lahir</td>
<td class="pinggir-data"><input type="date" name="tgllahir" size="30"></td></tr>
<tr><td class="pinggir-data">Pendidikan Terakhir</td>
<td class="pinggir-data"><input type="text" name="pendidikan" size="65"></td></tr>
<tr><td class="pinggir-data">Alamat</td></td>
<td class="pinggir-data"><input type="text" name="alamat" size="65"></td></tr>
<tr><td class="pinggir-data">No Telp/HP</td>
<td class="pinggir-data"><input type="text" name="nohp" size="65"></td></tr>
<tr><td class="pinggir-data">Kejuruan Pelatihan</td>
<td class="pinggir-data"><input type="text" name="kejuruan" size="65"></td></tr>
<tr><td colspan="2" align="center" class="head-data">
<input type="submit" value="Input">
</td></tr>
</table>
</form>

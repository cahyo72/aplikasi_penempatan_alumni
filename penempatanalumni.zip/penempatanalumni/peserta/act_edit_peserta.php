<?php
include "../include/koneksi_db.php"; //memanggil file koneksi_db.php
include "../include/fungsi2.php"; //memanggil file fungsi.php

//variabel _POST
$id		   = isset($_POST['id']) ? addslashes($_POST['id']) : "";
$ta     = isset($_POST['ta']) ? addslashes($_POST['ta']) : "";
$nama     = isset($_POST['nama']) ? addslashes($_POST['nama']) : "";
$tempatlahir = isset($_POST['tempatlahir']) ? addslashes($_POST['tempatlahir']) : "";
$tgllahir    = isset($_POST['tgllahir']) ? addslashes($_POST['tgllahir']) : "";
$pendidikan  = isset($_POST['pendidikan']) ? addslashes($_POST['pendidikan']) : "";
$alamat	   = isset($_POST['alamat']) ? addslashes($_POST['alamat']) : "";
$nohp  = isset($_POST['nohp']) ? addslashes($_POST['nohp']) : "";
$kejuruan  = isset($_POST['kejuruan']) ? addslashes($_POST['kejuruan']) : "";


if ($id == "") {
	echo "<script>alert('Pilih dulu data yang akan di-update');</script>";
	echo "<meta http-equiv='refresh' content='0; url=?page=peserta'>";
} else {
	$query = mysql_query("UPDATE peserta SET ta='$ta', nama='$nama', tempatlahir='$tempatlahir', tgllahir='$tgllahir', pendidikan='$pendidikan', alamat='$alamat', nohp='$nohp', kejuruan='$kejuruan' WHERE id='$id'", $konek);

	if ($query) {
		echo "<script>alert('Data berhasil diupdate @ $hari_ini.Terima Kasih')</script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=peserta'>";
	} else {
		Echo "Data anda gagal diupdate. Ulangi sekali lagi".mysql_error();
		echo "<meta http-equiv='refresh' content='0; url=?page=edit_peserta&id=$id'>";
	}
}
?>

<?php

include "../peserta/link.php";
include "../include/koneksi_db.php"; //memanggil file koneksi_db.php
include "../include/config.php"; //memanggil file fungsi.php

//tampilkan form pencarian
echo "<center><form action='' method='post'><input type='text' name='cari' value='Pencarian...' onfocus=\"this.value='';\" onblur=\"if(this.value=='') this.value='Pencarian...';\">&nbsp;&nbsp;<input type='submit' value='go' name='go'>&nbsp;&nbsp;&nbsp;*) masukkan nama alumni</form></scenter>";

//variabel _GET /
$hal	= isset($_GET['hal']) ? $_GET['hal'] : "";


//variabel _POST 
$cari	= isset($_POST['cari']) ? $_POST['cari'] : "";
$go		= isset($_POST['go']) ? $_POST['go'] : "";


$per_halaman	= 20;   // jumlah record data per halaman

if ($hal==""||$hal==1) {
	$awal=0;
} else {
	$awal=($hal*$per_halaman)-$per_halaman;
}
$batas=$per_halaman;




if ($go == "go" && $cari != "Pencarian...") {
	$query		= mysql_query("SELECT * FROM peserta WHERE ta LIKE '%$cari$' OR kejuruan LIKE '%$cari%' OR nama LIKE '%$cari%'", $konek);
	$j_cari		= mysql_num_rows($query);
	$jm_cari	= ceil($j_cari/$per_halaman);
} else if ($go == "" || $cari == "Pencarian...") {
	$query		=mysql_query("SELECT * FROM peserta ORDER BY id LIMIT $awal,$batas", $konek);
	$j_cari		= mysql_num_rows($query);
	$jm_cari	= ceil($j_cari/$per_halaman);
}


$query2=mysql_query("SELECT * FROM peserta");
$jumlah_peserta=mysql_num_rows($query2);
$jum_halaman=ceil($jumlah_peserta/$per_halaman);
//echo $jum_halaman;


if ($jum_halaman==1) { // ||$jm_cari<=10
echo "";
} else {
echo "<center><font size='3px'>Halaman : </font>";
for ($i=1; $i<=$jum_halaman; $i++) {
	if ($i==$hal) {
	echo "<font size='4px' color='green'>[<a href='?page=peserta&hal=$i'><b>$i</b></a>]</font>";
	} else {
	echo "<font size='2px' color='red'>[<a href='?page=peserta&hal=$i'><b>$i</b></a>]</font>";
	}
}
echo "</center><hr>";
}
?>
<table class="table-data" border=1 width=100% border=0 >
<tr><td class="td-data" colspan="7"><b>Jumlah Pencarian : <?php if ($j_cari==0) {echo "0";} else { echo $j_cari; } ?> eks. | Jumlah Keseluruhan peserta : <?php echo $jumlah_peserta; ?> eks.</b></td></tr>
<tr><td class="head-data">Nama</td><td class="head-data">alamat</td><td class="head-data">kejuruan</td><td class="head-data">Edit</td><td class="head-data">Hapus</td></tr>
<?php
while ($hasil=mysql_fetch_array($query)) {
echo "<tr><td class='pinggir-data'><a href='?page=detil_peserta&nama=$hasil[nama]'>$hasil[nama]</a></td>
      <td class='td-data'>$hasil[alamat]</td>
	  <td class='td-data'>$hasil[kejuruan]</td>
	  <td class='td-data'><a href='?page=edit_peserta&id=$hasil[id]'><img class='img_link' src='../image/edit.png' width='15px' height='15px'></a></td>
	  <td class='td-data'><a href='?page=act_hapus_peserta&id=$hasil[id]' onclick='return confirm(\"Anda yakin ingin menghapus data peserta $hasil[nama] ?\")'><img class='img_link' src='../image/delete.png' width='15px' height='15px'></a></td></tr>";
}
?>
</table>
<center>
	<form action='' method='post'>
		<font size='3px'>Jurusan : </font>
		<select name="jurusan">
			<option value="Desain">Desain Grafis</option>
			<option value="Menjahit">Menjahit</option>
			<option value="Pramuniaga">Pramuniaga</option>
			<option value="Terapi">Terapi Refleksologi</option>
			<option value="Otomotif">Otomotif</option>
		</select>
		&nbsp;&nbsp;<input type='submit' value='Cetak' name='cetak'>
	</form>
</center>

<?php
include "../include/koneksi_db.php"; //memanggil file koneksi_db.php


$id		= isset($_GET['id']) ? $_GET['id'] : "";


if ($id=="") {
	echo "<script>alert('Pilih dulu data yang akan di-hapus');</script>";
	echo "<meta http-equiv='refresh' content='0; url=?page=peserta'>";
} else {
	$query = mysql_query("DELETE FROM peserta WHERE id='$id'", $konek);

	if ($query) {
		echo "<script>alert('Data berhasil dihapus')</script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=peserta'>";
	} else {
		echo "Data anda gagal dihapus. Ulangi sekali lagi";
		echo "<meta http-equiv='refresh' content='0; url=?page=peserta'>";
	}
}

$query2 = "SELECT * FROM peserta ORDER BY id";
$hasil = mysql_query($query2);
$no=1;
while ($data = mysql_fetch_array($hasil))
{
	$id=$data['id'];
	$query3= "UPDATE peserta SET id=$no WHERE id=$id";
	mysql_query($query3);
	
	$no++;
}

$query="ALTER TABLE peserta AUTO_INCREMENT = $no";
mysql_query($query);

?>

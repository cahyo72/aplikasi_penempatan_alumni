<?php
include "../include/koneksi_db.php";
include "../lembaga/link.php";

$id		= isset($_GET['id']) ? $_GET['id'] : "";

if ($id == "") {
	echo "<script>alert('Pilih dulu data yang akan di-update');</script>";
	echo "<meta http-equiv='refresh' content='0; url=lihat_lembaga.php'>";
} else {
	$query		= mysql_query("SELECT * FROM lembaga WHERE id=$id", $konek);
	$hasil		= mysql_fetch_array($query);
	$id  		= $hasil['id'];
	$nama 		= $hasil['nama'];
	$alamat		= $hasil['alamat'];
	$telp		= $hasil['telp'];
	}
	
?>

<form method="post" action="?page=act_edit_lembaga">
<table width=100% border=1 class="table-data">
<input type="hidden" name="id" value="<?php echo $id; ?>">
<tr><td class="head-data" colspan="2">Edit Data lembaga : <?php echo $nama; ?></td></tr>
<tr><td class="pinggir-data">lembaga</td>
<td class="pinggir-data"><input type="text" size="55" name="nama" value="<?php echo $nama; ?>"></td></tr>
<tr><td class="pinggir-data">Alamat</td>
<td class="pinggir-data"><input type="text" size="20" name="alamat" value="<?php echo $alamat; ?>"></td></tr>
<tr><td class="pinggir-data">No Telp/HP</td>
<td class="pinggir-data"><input type="text" size="25" name="telp" value="<?php echo $telp; ?>"></td></tr>
<tr><td class="head-data" colspan="2" align="center">
<input type="submit" value="Update">
</td></tr>
</table>
</form>
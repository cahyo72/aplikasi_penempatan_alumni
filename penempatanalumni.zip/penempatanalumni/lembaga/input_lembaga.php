<?php include "../lembaga/link.php"; ?>
<form method="post" action="?page=act_input_lembaga">
<table width=100% border=1 class="table-data">
<tr><td class="head-data" colspan="2">Tambah Lembaga</td></tr>
<tr><td class="pinggir-data">Nama</td>
<td class="pinggir-data"><input type="text" name="nama" size="65"></td></tr>
<tr><td class="pinggir-data">Alamat</td></td>
<td class="pinggir-data"><input type="text" name="alamat" size="20"></td></tr>
<tr><td class="pinggir-data">No Telp/HP</td>
<td class="pinggir-data"><input type="text" name="telp" size="20"></td></tr>
<tr><td colspan="2" align="center" class="head-data">
<input type="submit" value="Input">
</td></tr>
</table>
</form>

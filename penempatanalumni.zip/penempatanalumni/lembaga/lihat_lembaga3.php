<?php

include "../peserta/link.php";
include "../include/koneksi_db.php"; //memanggil file koneksi_db.php
include "../include/config.php"; //memanggil file fungsi.php

$query=mysql_query("SELECT * FROM peserta ORDER BY id", $konek);
$jumlah_peserta=mysql_num_rows($query);
?>
<table class="table-data" border=1 width=100% border=0 >
<tr><td class="td-data" colspan="7"><b>Jumlah Keseluruhan peserta : <?php echo $jumlah_peserta; ?> eksemplar</b></td></tr>
<tr><td class="head-data">Nama</td><td class="head-data">Alamat</td><td class="head-data">No HPt</td><td class="head-data">Kejuruan</td><td class="head-data">Edit</td><td class="head-data">Hapus</td></tr>
<?php
while ($hasil=mysql_fetch_array($query)) {
echo "<tr><td class='pinggir-data'><a href='?page=detil_peserta&nama=$hasil[nama]'>$hasil[nama]</a></td>
      <td class='td-data'>$hasil[alamat]</td>
	  <td class='td-data'>$hasil[nohp]</td>
	  <td class='td-data'>$hasil[kejuruan]</td>
	  <td class='td-data'><a href='?page=edit_peserta&id=$hasil[id]'>Edit</a></td>
	  <td class='td-data'><a href='?page=act_hapus_peserta&id=$hasil[id]' onclick='return confirm(\"Anda yakin ingin menghapus data peserta $hasil[judul] ?\")'>Hapus</a></td></tr>";
}
?>
</table>
<?php
include "../include/koneksi_db.php"; //memanggil file koneksi_db.php
include "../include/fungsi2.php"; //memanggil file fungsi.php

//variabel _POST
$id		   = isset($_POST['id']) ? addslashes($_POST['id']) : "";
$nama     = isset($_POST['nama']) ? addslashes($_POST['nama']) : "";
$alamat	   = isset($_POST['alamat']) ? addslashes($_POST['alamat']) : "";
$telp  = isset($_POST['telp']) ? addslashes($_POST['telp']) : "";


if ($id == "") {
	echo "<script>alert('Pilih dulu data yang akan di-update');</script>";
	echo "<meta http-equiv='refresh' content='0; url=?page=lembaga'>";
} else {
	$query = mysql_query("UPDATE lembaga SET nama='$nama', alamat='$alamat', telp='$telp' WHERE id='$id'", $konek);

	if ($query) {
		echo "<script>alert('Data berhasil diupdate @ $hari_ini.Terima Kasih')</script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=lembaga'>";
	} else {
		Echo "Data anda gagal diupdate. Ulangi sekali lagi".mysql_error();
		echo "<meta http-equiv='refresh' content='0; url=?page=edit_lembaga&id=$id'>";
	}
}
?>

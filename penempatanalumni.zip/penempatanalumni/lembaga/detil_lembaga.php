<?php
include "../include/koneksi_db.php";
include "../lembaga/link.php";

$nama	= isset($_GET['nama']) ? $_GET['nama'] : "";

$query=mysql_query("SELECT * FROM lembaga WHERE nama='$nama'", $konek);
$hasil=mysql_fetch_array($query);
?>
<table class="table-data" width=100% border=1>
	<tr><td colspan="2" class="head-data">Data Detail lembaga : "<?php echo $nama; ?>"</td></tr>
	<tr><td class="pinggir-data">Nama</td><td class="pinggir-data"><?php echo $hasil[1]; ?></td></tr>
	<tr><td class="pinggir-data">Alamat</td><td class="pinggir-data"><?php echo $hasil[2]; ?></td></tr>
<tr><td class="pinggir-data">No Telp</td><td class="pinggir-data"><?php echo $hasil[3]; ?></td></tr>

	
	
</table>
	

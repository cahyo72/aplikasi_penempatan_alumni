<?php
include "../include/koneksi_db.php"; //memanggil file koneksi_db.php
include "../include/fungsi2.php"; //memanggil file fungsi.php

$nama		= isset($_POST['nama']) ? addslashes($_POST['nama']) : "";
$alamat		= isset($_POST['alamat']) ? addslashes($_POST['alamat']) : "";
$telp		= isset($_POST['telp']) ? addslashes($_POST['telp']) : "";



	$cek=mysql_query("SELECT * FROM lembaga WHERE nama='$nama'", $konek);
	$hasil_cek=mysql_num_rows($cek);

	$query = mysql_query("INSERT INTO lembaga VALUES (NULL, '$nama', '$alamat', '$telp')");

		if ($query) {
			echo "<script>alert('Data berhasil ditambahkan @ $hari_ini. Terima Kasih')</script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=lembaga'>";
		} else {
			echo "<script>alert('Data anda gagal dimasukkan karena. Ulangi sekali lagi')</script>";
			echo mysql_error();
			//echo "<meta http-equiv='refresh' content='0; url=?page=input_buku'>";
		}
?>